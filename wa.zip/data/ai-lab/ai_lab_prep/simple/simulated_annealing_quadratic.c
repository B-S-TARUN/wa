#include <stdio.h>
#include <stdlib.h>
#include <math.h>

double f(double x) { return -(x - 2) * (x - 2) + 7; }

int main(void) {
    srand(1);
    double x = 10, T = 100, best = x;
    for (int s = 0; s < 1000 && T > 0.001; s++, T *= 0.99) {
        double nx = x + (rand() % 41 - 20) / 10.0;
        double d = f(nx) - f(x);
        if (d > 0 || rand() / (double)RAND_MAX < exp(-d / T)) x = nx;
        if (f(x) > f(best)) best = x;
    }
    printf("max f(x) = %.3f at x = %.3f\n", f(best), best);
    return 0;
}
