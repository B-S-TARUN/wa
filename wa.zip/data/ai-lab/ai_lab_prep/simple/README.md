# simple — one-file, no-comment, minimal versions

| file | what it does |
|------|--------------|
| `astar.c` | A* search, f = g + h |
| `ucs.c` | uniform cost search, f = g (no heuristic) |
| `hill_climbing.c` | 8-queens steepest descent + restarts |
| `simulated_annealing.c` | 8-queens SA, accept worse with e^(-d/T) |
| `genetic.c` | maximize an 8-bit string |
| `minimax.c` | tic-tac-toe, minimax + alpha-beta (you = X, type 1-9) |
| `cryptarithmetic.c` | SEND + MORE = MONEY backtracking |
| `water_jug.c` | BFS shortest solution (4L, 3L, goal 2L in A) |
| `graph_coloring.c` | pentagon, 3 colors, backtracking |
| `hill_climbing_quadratic.c` | hill climb to max of f(x) = -(x-2)^2 + 7 |
| `simulated_annealing_quadratic.c` | SA to max of the same f(x) |

Compile & run:
```bash
gcc -Wall astar_ucs.c -o prog -lm && ./prog
```
(`-lm` only needed by the simulated_annealing ones; harmless everywhere.)

Sample minimax game: `printf "5\n9\n2\n4\n7\n" | ./minimax` → Draw.
