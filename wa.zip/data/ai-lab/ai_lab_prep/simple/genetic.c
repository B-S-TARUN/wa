#include <stdio.h>
#include <stdlib.h>
#define POP 6
#define BITS 8

int pop[POP][BITS];

int fit(int *g) {
    int v = 0;
    for (int i = 0; i < BITS; i++) v = v * 2 + g[i];
    return v;
}

int pick(int total) {
    int r = rand() % total, s = 0;
    for (int i = 0; i < POP; i++) {
        s += fit(pop[i]);
        if (s > r) return i;
    }
    return POP - 1;
}

int main(void) {
    srand(1);
    for (int i = 0; i < POP; i++)
        for (int j = 0; j < BITS; j++) pop[i][j] = rand() % 2;
    for (int gen = 0; gen < 30; gen++) {
        int total = 0, best = 0, np[POP][BITS];
        for (int i = 0; i < POP; i++) total += fit(pop[i]);
        if (!total) total = 1;
        for (int i = 1; i < POP; i++) if (fit(pop[i]) > fit(pop[best])) best = i;
        for (int j = 0; j < BITS; j++) np[0][j] = pop[best][j];
        for (int i = 1; i < POP; i++) {
            int p1 = pick(total), p2 = pick(total), cut = rand() % (BITS - 1) + 1;
            for (int j = 0; j < BITS; j++) np[i][j] = j < cut ? pop[p1][j] : pop[p2][j];
            for (int j = 0; j < BITS; j++) if (rand() % 100 < 5) np[i][j] ^= 1;
        }
        for (int i = 0; i < POP; i++)
            for (int j = 0; j < BITS; j++) pop[i][j] = np[i][j];
    }
    int best = 0;
    for (int i = 1; i < POP; i++) if (fit(pop[i]) > fit(pop[best])) best = i;
    printf("best = %d\n", fit(pop[best]));
    return 0;
}
