#include <stdio.h>

char b[9] = {' ',' ',' ',' ',' ',' ',' ',' ',' '};

int win(char p) {
    int L[8][3] = {{0,1,2},{3,4,5},{6,7,8},{0,3,6},{1,4,7},{2,5,8},{0,4,8},{2,4,6}};
    for (int i = 0; i < 8; i++)
        if (b[L[i][0]] == p && b[L[i][1]] == p && b[L[i][2]] == p) return 1;
    return 0;
}

int full(void) {
    for (int i = 0; i < 9; i++)
        if (b[i] == ' ') return 0;
    return 1;
}

int mm(int d, int max, int al, int be) {
    if (win('O')) return 10 - d;
    if (win('X')) return d - 10;
    if (full()) return 0;
    int best = max ? -100 : 100;
    for (int i = 0; i < 9; i++) {
        if (b[i] != ' ') continue;
        b[i] = max ? 'O' : 'X';
        int v = mm(d + 1, !max, al, be);
        b[i] = ' ';
        if (max) { if (v > best) best = v; if (best > al) al = best; }
        else     { if (v < best) best = v; if (best < be) be = best; }
        if (be <= al) break;
    }
    return best;
}

void show(void) {
    for (int r = 0; r < 3; r++)
        printf("%c|%c|%c\n", b[3*r], b[3*r+1], b[3*r+2]);
}

int main(void) {
    int cell;
    while (scanf("%d", &cell) == 1) {
        if (cell < 1 || cell > 9 || b[cell-1] != ' ') continue;
        b[cell-1] = 'X';
        if (win('X') || full()) break;
        int bv = -100, mv = -1;
        for (int i = 0; i < 9; i++) {
            if (b[i] != ' ') continue;
            b[i] = 'O';
            int v = mm(1, 0, -100, 100);
            b[i] = ' ';
            if (v > bv) { bv = v; mv = i; }
        }
        b[mv] = 'O';
        printf("computer: %d\n", mv + 1);
        if (win('O') || full()) break;
    }
    show();
    if (win('X')) printf("You win\n");
    else if (win('O')) printf("Computer wins\n");
    else if (full()) printf("Draw\n");
    return 0;
}
