#include <stdio.h>
#define N 5
#define INF 9999

int cost[N][N] = {{0,1,4,0,0},{0,0,2,5,12},{0,0,0,2,0},{0,0,0,0,3},{0,0,0,0,0}};
int h[N] = {7,6,4,3,0};
char *nm = "SABCG";

int main(void) {
    int g[N], par[N], done[N], path[N], len = 0;
    for (int i = 0; i < N; i++) { g[i] = INF; par[i] = -1; done[i] = 0; }
    g[0] = 0;
    for (int s = 0; s < N; s++) {
        int u = -1, best = INF;
        for (int i = 0; i < N; i++)
            if (!done[i] && g[i] + h[i] < best) { best = g[i] + h[i]; u = i; }
        if (u < 0) break;
        done[u] = 1;
        if (u == N - 1) break;
        for (int i = 0; i < N; i++)
            if (cost[u][i] && g[u] + cost[u][i] < g[i]) { g[i] = g[u] + cost[u][i]; par[i] = u; }
    }
    printf("A*: ");
    if (g[N-1] == INF) { printf("no path\n"); return 0; }
    for (int v = N - 1; v != -1; v = par[v]) path[len++] = v;
    for (int i = len - 1; i >= 0; i--) printf("%c%s", nm[path[i]], i ? " -> " : "");
    printf("  cost %d\n", g[N-1]);
    return 0;
}
