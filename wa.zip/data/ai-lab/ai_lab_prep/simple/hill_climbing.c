#include <stdio.h>
#include <stdlib.h>
#define N 8

int board[N];

int h(void) {
    int a = 0;
    for (int i = 0; i < N; i++)
        for (int j = i + 1; j < N; j++)
            if (board[i] == board[j] || abs(board[i] - board[j]) == j - i) a++;
    return a;
}

int main(void) {
    srand(1);
    for (int t = 0; t < 100; t++) {
        for (int c = 0; c < N; c++) board[c] = rand() % N;
        for (;;) {
            int cur = h(), best = cur, bc = -1, br = 0;
            for (int c = 0; c < N; c++)
                for (int r = 0; r < N; r++) {
                    if (r == board[c]) continue;
                    int keep = board[c];
                    board[c] = r;
                    if (h() < best) { best = h(); bc = c; br = r; }
                    board[c] = keep;
                }
            if (bc == -1) break;
            board[bc] = br;
        }
        if (h() == 0) break;
    }
    printf("h = %d\n", h());
    for (int r = 0; r < N; r++) {
        for (int c = 0; c < N; c++) printf(board[c] == r ? "Q " : ". ");
        printf("\n");
    }
    return 0;
}
