#include <stdio.h>

double f(double x) { return -(x - 2) * (x - 2) + 7; }

int main(void) {
    double x = 0, step = 1;
    while (step > 0.001) {
        if (f(x + step) > f(x)) x += step;
        else if (f(x - step) > f(x)) x -= step;
        else step /= 2;
    }
    printf("max f(x) = %.3f at x = %.3f\n", f(x), x);
    return 0;
}
