#include <stdio.h>

int d[8], used[10];

void solve(int k) {
    if (k == 8) {
        int send  = d[0]*1000 + d[1]*100 + d[2]*10 + d[3];
        int more  = d[4]*1000 + d[5]*100 + d[6]*10 + d[1];
        int money = d[4]*10000 + d[5]*1000 + d[2]*100 + d[1]*10 + d[7];
        if (send + more == money)
            printf("%d + %d = %d\n", send, more, money);
        return;
    }
    for (int x = 0; x <= 9; x++) {
        if (used[x] || ((k == 0 || k == 4) && x == 0)) continue;
        used[x] = 1;
        d[k] = x;
        solve(k + 1);
        used[x] = 0;
    }
}

int main(void) {
    solve(0);
    return 0;
}
