#include <stdio.h>
#define A 4
#define B 3

int vis[A + 1][B + 1], pa[A + 1][B + 1], pb[A + 1][B + 1];
int qa[64], qb[64], head, tail;

int main(void) {
    int a, b, na, nb, t, found = 0, hist[64][2], n = 0;
    vis[0][0] = 1;
    qa[tail] = 0;
    qb[tail] = 0;
    tail++;
    while (head < tail) {
        a = qa[head];
        b = qb[head];
        head++;
        if (a == 2) { found = 1; break; }
        for (int op = 0; op < 6; op++) {
            na = a;
            nb = b;
            if (op == 0) na = A;
            if (op == 1) nb = B;
            if (op == 2) na = 0;
            if (op == 3) nb = 0;
            if (op == 4) { t = a < B - b ? a : B - b; na = a - t; nb = b + t; }
            if (op == 5) { t = b < A - a ? b : A - a; na = a + t; nb = b - t; }
            if ((na == a && nb == b) || vis[na][nb]) continue;
            vis[na][nb] = 1;
            pa[na][nb] = a;
            pb[na][nb] = b;
            qa[tail] = na;
            qb[tail] = nb;
            tail++;
        }
    }
    if (!found) { printf("no solution\n"); return 0; }
    while (a || b) {
        hist[n][0] = a;
        hist[n][1] = b;
        n++;
        t = pa[a][b];
        b = pb[a][b];
        a = t;
    }
    for (int i = n - 1; i >= 0; i--) printf("(%d,%d)\n", hist[i][0], hist[i][1]);
    printf("(0,0)\n");
    return 0;
}
