#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#define N 8

int b[N], best[N], bh;

int h(void) {
    int a = 0;
    for (int i = 0; i < N; i++)
        for (int j = i + 1; j < N; j++)
            if (b[i] == b[j] || abs(b[i] - b[j]) == j - i) a++;
    return a;
}

int main(void) {
    srand(42);
    double T = 100;
    for (int i = 0; i < N; i++) b[i] = rand() % N;
    bh = h();
    for (int i = 0; i < N; i++) best[i] = b[i];
    for (int s = 0; s < 10000 && T > 0.001 && bh > 0; s++, T *= 0.99) {
        int cur = h(), c = rand() % N, r;
        do r = rand() % N; while (r == b[c]);
        int keep = b[c];
        b[c] = r;
        int d = h() - cur;
        if (d <= 0 || (double)rand() / RAND_MAX < exp(-d / T)) {
            if (h() < bh) {
                bh = h();
                for (int i = 0; i < N; i++) best[i] = b[i];
            }
        } else b[c] = keep;
    }
    printf("best h = %d\n", bh);
    for (int r = 0; r < N; r++) {
        for (int c = 0; c < N; c++) printf(best[c] == r ? "Q " : ". ");
        printf("\n");
    }
    return 0;
}
