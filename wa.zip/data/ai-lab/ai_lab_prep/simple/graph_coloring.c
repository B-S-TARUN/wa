#include <stdio.h>
#define N 5

int adj[N][N] = {{0,1,0,0,1},{1,0,1,0,0},{0,1,0,1,0},{0,0,1,0,1},{1,0,0,1,0}};
int color[N], m = 3;

int safe(int v, int c) {
    for (int i = 0; i < N; i++)
        if (adj[v][i] && color[i] == c) return 0;
    return 1;
}

int solve(int v) {
    if (v == N) return 1;
    for (int c = 1; c <= m; c++) {
        if (safe(v, c)) {
            color[v] = c;
            if (solve(v + 1)) return 1;
            color[v] = 0;
        }
    }
    return 0;
}

int main(void) {
    if (solve(0))
        for (int v = 0; v < N; v++) printf("%c=%d ", 'A' + v, color[v]);
    else
        printf("no solution with %d colors\n", m);
    printf("\n");
    return 0;
}
