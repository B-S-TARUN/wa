#include<stdio.h>

int digit[8];
int used[10];

void solve(int i)
{
	if(i==8)
	{
		int S=digit[0],E=digit[1],N=digit[2],D=digit[3];
		int M=digit[4],O=digit[5],R=digit[6];
		int Y=digit[7];

		int send=S*1000+E*100+N*10+D;
		int more=M*1000+O*100+R*10+E;
		int money=M*10000+O*1000+N*100+E*10+Y;

		if(send+more==money)
			printf("%d + %d = %d\n",send,more,money);
		return;
	}

	for(int d=0;d<=9;d++)
	{
		if(used[d]) continue;
		if(d==0 && (i==0 || i==4)) continue;

		used[d]=1;
		digit[i]=d;
		solve(i+1);
		used[d]=0;
	}
}

int main()
{
	solve(0);
	return 0;
}
