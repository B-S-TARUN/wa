#include<stdio.h>

int graph[100][100];
int cost[100][100];
int dist[100];
int parent[100];
int open[100];
int close[100];
int n,s,g;

int is_open(int open[100])
{
	for(int i=0;i<100;i++)
		if(open[i]) return 1;
	return 0;
}

void init()
{
	for(int i=0;i<n;i++)
	{
		dist[i]=99999;
		parent[i]=-1;
		open[i]=0;
		close[i]=0;
	}
}

int min_dist()
{
	int min=99999,mini=-1;
	for(int i=0;i<n;i++)
	{
		if(!close[i] && dist[i]<min)
		{
			min=dist[i];
			mini=i;
		}
	}
	return mini;
}

int main()
{
	scanf("%d",&n);
	for(int i=0;i<n;i++)
		for(int j=0;j<n;j++)
			scanf("%d",&graph[i][j]);
	for(int i=0;i<n;i++)
		for(int j=0;j<n;j++)
			scanf("%d",&cost[i][j]);
	scanf("%d %d",&s,&g);

	init();
	dist[s]=0;
	open[s]=1;

	while(is_open(open))
	{
		int u=min_dist();
		if(u==-1) break;
		if(u==g)
		{
			printf("Goal found\n");
			printf("Cost: %d\n",dist[g]);
			return 0;
		}
		open[u]=0;
		close[u]=1;
		for(int v=0;v<n;v++)
		{
			if(graph[u][v] && !close[v])
			{
				int new_cost=dist[u]+cost[u][v];
				if(new_cost<dist[v])
				{
					dist[v]=new_cost;
					parent[v]=u;
				}
				open[v]=1;
			}
		}
	}
	printf("No path\n");
	return 0;
}
