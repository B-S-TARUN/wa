#include<stdio.h>

#define JUG1_CAPACITY 5
#define JUG2_CAPACITY 3

int visited[100];
int parent[100];
int path[100];
int path_len=0;

void print_path(int state)
{
	printf("State: (%d, %d)\n", state/JUG2_CAPACITY, state%JUG2_CAPACITY);
}

void print_solution(int state)
{
	print_path(state);
	while(parent[state]!=-1)
	{
		state=parent[state];
		print_path(state);
	}
}

int is_goal(int state)
{
	return state%JUG2_CAPACITY==0;
}

int get_state(int *m, int *n)
{
	scanf("%d %d", m, n);
	return (*m)*JUG2_CAPACITY+(*n);
}

int solve()
{
	int start=JUG1_CAPACITY*JUG2_CAPACITY;
	for(int i=0;i<start;i++)
	{
		visited[i]=-1;
		parent[i]=-1;
	}
	int queue[100];
	int front=0, rear=0;
	queue[rear++]=0;
	visited[0]=0;
	parent[0]=-1;

	while(front<rear)
	{
		int state=queue[front++];
		int m=state/JUG2_CAPACITY;
		int n=state%JUG2_CAPACITY;

		if(is_goal(state))
		{
			print_solution(state);
			return 0;
		}

		int next_state;
		int next_idx;

		// Fill Jug1
		next_state=(JUG1_CAPACITY)*JUG2_CAPACITY+n;
		next_idx=next_state;
		if(visited[next_idx]==-1)
		{
			visited[next_idx]=1;
			parent[next_idx]=state;
			queue[rear++]=next_idx;
		}

		// Fill Jug2
		next_state=m*JUG2_CAPACITY+JUG2_CAPACITY;
		next_idx=next_state;
		if(visited[next_idx]==-1)
		{
			visited[next_idx]=1;
			parent[next_idx]=state;
			queue[rear++]=next_idx;
		}

		// Empty Jug1
		next_state=0;
		next_idx=next_state;
		if(visited[next_idx]==-1)
		{
			visited[next_idx]=1;
			parent[next_idx]=state;
			queue[rear++]=next_idx;
		}

		// Empty Jug2
		next_state=m*JUG2_CAPACITY+0;
		next_idx=next_state;
		if(visited[next_idx]==-1)
		{
			visited[next_idx]=1;
			parent[next_idx]=state;
			queue[rear++]=next_idx;
		}

		// Pour from Jug1 to Jug2
		int amount=JUG2_CAPACITY-n;
		if(m<amount) amount=m;
		int nm=m-amount;
		int nn=n+amount;
		next_state=nm*JUG2_CAPACITY+nn;
		next_idx=next_state;
		if(visited[next_idx]==-1)
		{
			visited[next_idx]=1;
			parent[next_idx]=state;
			queue[rear++]=next_idx;
		}

		// Pour from Jug2 to Jug1
		amount=JUG1_CAPACITY-m;
		if(n<amount) amount=n;
		nm=m+amount;
		nn=n-amount;
		next_state=nm*JUG2_CAPACITY+nn;
		next_idx=next_state;
		if(visited[next_idx]==-1)
		{
			visited[next_idx]=1;
			parent[next_idx]=state;
			queue[rear++]=next_idx;
		}
	}
	printf("No solution\n");
	return 1;
}

int main()
{
	solve();
	return 0;
}
