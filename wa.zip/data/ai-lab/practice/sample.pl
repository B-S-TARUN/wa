% sample.pl — classic Prolog patterns: list recursion, fact/rule, arithmetic

% Fact: a member belongs to a list
member(X, [X|_]).
member(X, [_|T]) :- member(X, T).

% Fact: direct edge between two nodes
edge(a, b).
edge(b, c).
edge(c, d).
edge(a, c).

% Rule: path from A to B (recursive)
path(X, Y) :- edge(X, Y).
path(X, Y) :- edge(X, Z), path(Z, Y).

% Rule: reverse a list (simple recursive)
reverse([], []).
reverse([H|T], R) :- reverse(T, RT), append(RT, [H], R).

% Helper: append two lists
append([], L, L).
append([H|T], L, [H|R]) :- append(T, L, R).

% Query example (commented out):
% ?- member(b, [a, b, c]).
% ?- path(a, d).
% ?- reverse([1, 2, 3], R).

:- initialization(main).

main :-
    write('member(b, [a,b,c]) => '), member(b, [a, b, c]), !, nl,
    write('path(a, d) => '), path(a, d), !, nl,
    write('reverse([1,2,3]) => '), reverse([1, 2, 3], R), write(R), !, nl.
