#include<stdio.h>

#define V 5

int graph[V][V];
int color[V];
int result[V];

void print_solution()
{
	printf("Solution exists:\n");
	for(int i=0;i<V;i++)
		printf("Vertex %d ---> Color %d\n",i,result[i]);
	printf("\n");
}

int is_safe(int v, int c)
{
	for(int i=0;i<V;i++)
	{
		if(graph[v][i] && c==color[i])
			return 0;
	}
	return 1;
}

int graph_coloring(int v)
{
	if(v==V)
	{
		for(int i=0;i<V;i++)
			result[i]=color[i];
		print_solution();
		return 1;
	}

	for(int c=1;c<=V;c++)
	{
		if(is_safe(v,c))
		{
			color[v]=c;
			graph_coloring(v+1);
			color[v]=0;
		}
	}
	return 0;
}

int main()
{
	for(int i=0;i<V;i++)
	{
		for(int j=0;j<V;j++)
			scanf("%d",&graph[i][j]);
	}
	for(int i=0;i<V;i++)
		color[i]=0;

	graph_coloring(0);
	return 0;
}
