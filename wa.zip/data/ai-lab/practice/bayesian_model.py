import numpy as np

# Manually allocated probability values for a simple Bayesian model
# Model: P(A, B, C) with conditional dependencies:
#   A -> B
#   A -> C
#   B -> C

# Prior: P(A)
P_A = np.array([0.4, 0.6])  # A = [False, True]

# Conditional: P(B | A)
#  P(B=False | A=False) = 0.7, P(B=True | A=False) = 0.3
#  P(B=False | A=True)  = 0.2, P(B=True | A=True)  = 0.8
P_B_given_A = np.array([
    [0.7, 0.3],  # A=False
    [0.2, 0.8],  # A=True
])

# Conditional: P(C | A, B)
#  P(C=False | A, B), P(C=True | A, B)
P_C_given_AB = np.array([
    [
        [0.9, 0.1],  # A=False, B=False
        [0.6, 0.4],  # A=False, B=True
    ],
    [
        [0.3, 0.7],  # A=True,  B=False
        [0.1, 0.9],  # A=True,  B=True
    ],
])

# Joint probability P(A, B, C)
# Manual allocation (no normalization step — just the raw joint table)
def joint(A, B, C):
    """Compute joint probability from the manually allocated values."""
    p_a = P_A[A]
    p_b_given_a = P_B_given_A[A, B]
    p_c_given_ab = P_C_given_AB[A, B, C]
    return p_a * p_b_given_a * p_c_given_ab

# Manual evidence E: P(A | E) computed via Bayes' rule
# Evidence: C is True (C=1)
# P(A | C=T) ∝ P(C=T | A) * P(A)
def p_c_true_given_a(a):
    """P(C=True | A=a) computed by summing over B."""
    total = 0.0
    for b in (0, 1):
        p_b = P_B_given_A[a, b]
        p_c = P_C_given_AB[a, b, 1]  # C=True
        total += p_b * p_c
    return total

def posterior_a_given_c_true():
    """P(A | C=True) using Bayes' rule: P(A|C) ∝ P(C|A)*P(A)."""
    numerator = np.array([p_c_true_given_a(a) * P_A[a] for a in (0, 1)])
    evidence = numerator.sum()
    return numerator / evidence

if __name__ == "__main__":
    print("=== Manually allocated probability values ===")
    print("P(A):", P_A)
    print("P(B|A):\n", P_B_given_A)
    print("P(C|A,B) shape:", P_C_given_AB.shape)

    print("\n=== Joint P(A,B,C) queries ===")
    for a in (0, 1):
        for b in (0, 1):
            for c in (0, 1):
                p = joint(a, b, c)
                print(f"P(A={a}, B={b}, C={c}) = {p:.4f}")

    print("\n=== Posterior P(A | C=True) via Bayes' rule ===")
    post = posterior_a_given_c_true()
    print(f"P(A=False | C=True) = {post[0]:.4f}")
    print(f"P(A=True  | C=True) = {post[1]:.4f}")
