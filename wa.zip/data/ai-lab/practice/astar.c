#include<stdio.h>

int graph[100][100];
int h[100];
int open[100];
int close[100];
int n,s,g;

int is_open(int open[100])
{
	for(int i=0;i<100;i++)
		if(open[i]) return 1;
	return 0;
}

int main()
{
	scanf("%d",&n);
	for(int i=0;i<n;i++)
		for(int j=0;j<n;j++)
			scanf("%d",&graph[i][j]);
	for(int i=0;i<n;i++)
		scanf("%d",&h[i]);
	scanf("%d %d",&s,&g);

	open[s]=1;
	while(is_open(open))
	{
		int min=999,mini=-1;
		for(int i=0;i<n;i++)
		{
			if(open[i] && min>h[i])
			{
				min=h[i];
				mini=i;
			}
		}
		if(mini==g)
		{
			printf("Goal found");
			return 0;
		}
		if(min==999)
		{
			printf("No path");
			return 0;
		}
		printf("min i:%d\n",mini);
		open[mini]=0;
		close[mini]=1;
		for(int j=0;j<n;j++)
		{
			if(close[j]!=1 && graph[mini][j])
				open[j]=1;
		}
	}
	return 0;
}
