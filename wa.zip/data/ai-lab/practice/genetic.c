#include<stdio.h>
#include<stdlib.h>

#define POP 6
#define BITS 5

int p[POP][BITS];
int fitness[POP];
int total_fitness=0;
float mp=0.05;
int best[BITS];
int max_fitness=-1;
void init()
{
	for(int i=0;i<POP;i++)
	{
		for(int j=0;j<BITS;j++)
		{
			p[i][j]=rand()%2;
		}
	}
}

void f()
{
	total_fitness=0;
	for(int i=0;i<POP;i++)
	{
		int fit=0;
		for(int j=0;j<BITS;j++)
		{
			fit=fit*2+p[i][j];
		}
		fitness[i]=fit;
		total_fitness+=fit;
		if(fit>max_fitness) 
		{	
			max_fitness=fit;
			for(int j=0;j<BITS;j++) best[j]=p[i][j];
		}
	}
}

int select_parent()
{
	int r=rand()%total_fitness;
	int sum=0;
	for(int i=0;i<POP;i++)
	{
		sum+=fitness[i];
		if(r<sum)
			return i;
	}
	return POP-1;
}

int generate_child(int p[POP][BITS])
{
	int child[POP][BITS];
	for(int i=0;i<POP;i+=2)
	{
		int p1=select_parent();
		int p2=select_parent();
		int r=rand()%BITS;				for(int j=0;j<r;j++)
				{
					child[i][j]=p[p1][j];
					child[i+1][j]=p[p2][j];
				}
		for(int j=r;j<BITS;j++)
		{
			child[i][j]=p[p2][j];
			child[i+1][j]=p[p1][j];
		}
	}
	for(int i=0;i<POP;i++)
		for(int j=0;j<BITS;j++)
			if((double)rand()/RAND_MAX<mp)
				child[i][j]=1-child[i][j];
	
	for(int i=0;i<POP;i++)
		for(int j=0;j<BITS;j++)				p[i][j]=child[i][j];
	return 0;
}

int main()
{
	int n=20;
	init();
	for(int i=0;i<n;i++)
	{
		f();
		printf("%d Best fitness:%d\n",i,max_fitness);
		generate_child(p);
	}
	printf("The best on %d iterations:\n",n);
	for(int i=0;i<BITS;i++)
		printf("%d",best[i]);
	return 0;
}

