#include<stdio.h>
#include<stdlib.h>

#define N 3

int board[N][N];
int best_move[N][N];

int is_full()
{
	for(int i=0;i<N;i++)
		for(int j=0;j<N;j++)
			if(board[i][j]==0) return 0;
	return 1;
}

int check_winner(int player)
{
	for(int i=0;i<N;i++)
	{
		if(board[i][0]==player && board[i][1]==player && board[i][2]==player) return 1;
		if(board[0][i]==player && board[1][i]==player && board[2][i]==player) return 1;
	}
	if(board[0][0]==player && board[1][1]==player && board[2][2]==player) return 1;
	if(board[0][2]==player && board[1][1]==player && board[2][0]==player) return 1;
	return 0;
}

int minimax(int player)
{
	int win=check_winner(player);
	int loss=check_winner(player==1?2:1);
	if(win) return 10;
	if(loss) return -10;
	if(is_full()) return 0;

	int score,best;
	if(player==1)
	{
		best=-999;
		for(int i=0;i<N;i++)
			for(int j=0;j<N;j++)
			{
				if(board[i][j]==0)
				{
					board[i][j]=1;
					score=minimax(2);
					board[i][j]=0;
					if(score>best) best=score;
				}
			}
	}
	else
	{
		best=999;
		for(int i=0;i<N;i++)
			for(int j=0;j<N;j++)
			{
				if(board[i][j]==0)
				{
					board[i][j]=-1;
					score=minimax(1);
					board[i][j]=0;
					if(score<best) best=score;
				}
			}
	}
	return best;
}

int find_best_move()
{
	int best=-999;
	for(int i=0;i<N;i++)
		for(int j=0;j<N;j++)
		{
			if(board[i][j]==0)
			{
				board[i][j]=1;
				int score=minimax(2);
				board[i][j]=0;
				if(score>best)
				{
					best=score;
					best_move[i][j]=1;
				}
				else best_move[i][j]=0;
			}
		}
	return best;
}

void print_board()
{
	for(int i=0;i<N;i++)
	{
		for(int j=0;j<N;j++)
			printf("%d ",board[i][j]);
		printf("\n");
	}
}

int main()
{
	for(int i=0;i<N;i++)
		for(int j=0;j<N;j++)
			board[i][j]=0;

	print_board();
	int score=find_best_move();
	printf("Best score: %d\n",score);
	print_board();
	return 0;
}
