#include<stdio.h>
#include<stdlib.h>
#include<math.h>

double f(double x)
{
	return 2*x*x+4*x+2;
}

int main()
{
	float T=0.8,cr=0.8;
	double x,nx,fx,fnx,bx=999;
	x=(double)rand()/rand();
	while(T>.001)
	{
		nx=x+(2.0*rand()/RAND_MAX-1.0);
		fx=f(x);
		if(bx>fx) bx=fx;
		fnx=f(nx);
		printf("f(%f)=%f f(%f)=%f\n",x,fx,nx,fnx);
		if(fnx<fx)
		{
			x=nx;
		}
		else
		{
			double p=exp(-(fnx-fx)/T);
			double r=(double)rand()/RAND_MAX;
			if(p>=r)
				x=nx;
		}
		T*=cr;
	}
}

