// ================================================================
// EXPERIMENT 7a : Simple TCP Client
// ================================================================
// Sends a message to the server and receives the reply.
// Run:  java Exp7_TCPClient     (after starting the server)
// ================================================================
import java.io.*;
import java.net.*;

public class Exp7_TCPClient {
    public static void main(String[] args) throws Exception {
        Socket s = new Socket("localhost", 5000);     // connect to server
        System.out.println("Connected to server on port 5000");

        BufferedReader in  = new BufferedReader(
                new InputStreamReader(s.getInputStream()));
        PrintWriter out = new PrintWriter(s.getOutputStream(), true);
        BufferedReader kb = new BufferedReader(
                new InputStreamReader(System.in));

        String msg;
        while (true) {
            System.out.print("Client: ");
            out.println(kb.readLine());               // send

            msg = in.readLine();                      // receive reply
            if (msg == null || msg.equalsIgnoreCase("exit")) break;
            System.out.println("Server: " + msg);
        }
        s.close();
        System.out.println("Client closed.");
    }
}
