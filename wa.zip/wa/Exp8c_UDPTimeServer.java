// ================================================================
// EXPERIMENT 8c : TIME SERVER (UDP)
// ================================================================
// Client sends any request packet; server replies with the
// current date & time as a datagram packet.
// Run:  java Exp8c_UDPTimeServer   (start BEFORE the client)
// ================================================================
import java.net.*;
import java.util.Date;

public class Exp8c_UDPTimeServer {
    public static void main(String[] args) throws Exception {
        DatagramSocket ds = new DatagramSocket(8000);
        System.out.println("UDP Time Server listening on port 8000...");
        byte[] buf = new byte[256];

        while (true) {
            DatagramPacket req = new DatagramPacket(buf, buf.length);
            ds.receive(req);                                  // wait for request

            byte[] time = new Date().toString().getBytes();   // current time
            DatagramPacket res = new DatagramPacket(time, time.length,
                    req.getAddress(), req.getPort());
            ds.send(res);                                     // send time
        }
    }
}
