// ================================================================
// EXPERIMENT 7a : Simple TCP Server
// ================================================================
// Receives a message from the client and sends a reply.
// Run:  java Exp7_TCPServer     (start BEFORE the client)
// ================================================================
import java.io.*;
import java.net.*;

public class Exp7_TCPServer {
    public static void main(String[] args) throws Exception {
        ServerSocket ss = new ServerSocket(5000);
        System.out.println("Server started. Waiting on port 5000...");

        Socket s = ss.accept();                       // wait for client
        System.out.println("Client connected: " + s.getInetAddress());

        BufferedReader in  = new BufferedReader(
                new InputStreamReader(s.getInputStream()));
        PrintWriter out = new PrintWriter(s.getOutputStream(), true);
        BufferedReader kb = new BufferedReader(
                new InputStreamReader(System.in));

        String msg;
        while (true) {
            msg = in.readLine();                      // receive
            if (msg == null || msg.equalsIgnoreCase("exit")) break;
            System.out.println("Client: " + msg);

            System.out.print("Server: ");
            out.println(kb.readLine());               // send reply
        }
        s.close();
        ss.close();
        System.out.println("Server closed.");
    }
}
