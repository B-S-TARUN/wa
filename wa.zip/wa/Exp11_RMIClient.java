// ================================================================
// EXPERIMENT 11 : RMI CLIENT
// ================================================================
import java.rmi.*;

public class Exp11_RMIClient {
    public static void main(String[] args) throws Exception {
        // lookup the remote object registered by the server
        Addition a = (Addition) Naming.lookup("rmi://localhost/Addition");

        int x = 10, y = 20;
        System.out.println("Client: calling remote add(" + x + "," + y + ")...");
        System.out.println("Result from server = " + a.add(x, y));
    }
}
