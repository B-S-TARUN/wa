// ================================================================
// EXPERIMENT 8c : TIME CLIENT (UDP)
// ================================================================
// Sends a request packet to the UDP time server and prints the
// date & time received back.
// Run:  java Exp8c_UDPTimeClient   (after starting the server)
// ================================================================
import java.net.*;

public class Exp8c_UDPTimeClient {
    public static void main(String[] args) throws Exception {
        DatagramSocket ds = new DatagramSocket();
        InetAddress server = InetAddress.getByName("localhost");

        // send an empty request packet
        byte[] req = "TIME?".getBytes();
        ds.send(new DatagramPacket(req, req.length, server, 8000));

        // receive the reply
        byte[] buf = new byte[256];
        DatagramPacket res = new DatagramPacket(buf, buf.length);
        ds.receive(res);
        System.out.println("Current server time (UDP): " +
                new String(res.getData(), 0, res.getLength()));
        ds.close();
    }
}
