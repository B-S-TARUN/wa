package com.example;

import java.sql.SQLException;
import java.util.List;
import java.util.Scanner;

public class Main {

    private static final Scanner scanner = new Scanner(System.in);
    private static final BookDAO bookDAO = new BookDAO();

    public static void main(String[] args) {
        // Initialize the database
        DBConnection.initializeDatabase();

        System.out.println("========================================");
        System.out.println("  JDBC Application - Book Management   ");
        System.out.println("========================================");

        boolean exit = false;
        while (!exit) {
            showMenu();
            int choice = getIntInput("Enter your choice: ");

            try {
                switch (choice) {
                    case 1:
                        listAllBooks();
                        break;
                    case 2:
                        viewBookById();
                        break;
                    case 3:
                        addNewBook();
                        break;
                    case 4:
                        updateBook();
                        break;
                    case 5:
                        deleteBook();
                        break;
                    case 6:
                        searchByCategory();
                        break;
                    case 7:
                        searchByYear();
                        break;
                    case 8:
                        printSummary();
                        break;
                    case 9:
                        System.out.println("Thank you for using the application. Goodbye!");
                        exit = true;
                        break;
                    default:
                        System.out.println("Invalid choice. Please try again.");
                }
            } catch (SQLException e) {
                System.err.println("Database error: " + e.getMessage());
                e.printStackTrace();
            }
        }

        scanner.close();
        DBConnection.closeConnection();
    }

    private static void showMenu() {
        System.out.println("\n----------------------------------------");
        System.out.println("Main Menu:");
        System.out.println("  1. List all books");
        System.out.println("  2. View book by ID");
        System.out.println("  3. Add new book");
        System.out.println("  4. Update book");
        System.out.println("  5. Delete book");
        System.out.println("  6. Search by category");
        System.out.println("  7. Search by year");
        System.out.println("  8. Database summary");
        System.out.println("  9. Exit");
        System.out.println("----------------------------------------");
    }

    private static void listAllBooks() throws SQLException {
        System.out.println("\n--- All Books ---");
        List<Book> books = bookDAO.selectAll();
        if (books.isEmpty()) {
            System.out.println("No books found in the database.");
        } else {
            for (Book book : books) {
                System.out.println(book);
            }
        }
    }

    private static void viewBookById() throws SQLException {
        System.out.println("\n--- View Book by ID ---");
        int id = getIntInput("Enter book ID: ");
        Book book = bookDAO.selectById(id);
        if (book != null) {
            System.out.println(book);
        } else {
            System.out.println("Book with ID " + id + " not found.");
        }
    }

    private static void addNewBook() throws SQLException {
        System.out.println("\n--- Add New Book ---");
        String title = getStringInput("Enter title: ");
        String author = getStringInput("Enter author: ");
        int year = getIntInput("Enter year: ");
        String category = getStringInput("Enter category: ");

        Book book = new Book(0, title, author, year, category);
        int id = bookDAO.insert(book);
        System.out.println("Book added successfully with ID: " + id);
    }

    private static void updateBook() throws SQLException {
        System.out.println("\n--- Update Book ---");
        int id = getIntInput("Enter book ID to update: ");
        Book existing = bookDAO.selectById(id);
        if (existing == null) {
            System.out.println("Book with ID " + id + " not found.");
            return;
        }
        System.out.println("Current: " + existing);

        String title = getStringInput("Enter new title (or press Enter to keep '" + existing.getTitle() + "'): ");
        String author = getStringInput("Enter new author (or press Enter to keep '" + existing.getAuthor() + "'): ");
        String yearStr = getStringInput("Enter new year (or press Enter to keep " + existing.getYear() + "): ");
        String category = getStringInput("Enter new category (or press Enter to keep '" + existing.getCategory() + "'): ");

        if (!title.isEmpty()) existing.setTitle(title);
        if (!author.isEmpty()) existing.setAuthor(author);
        if (!yearStr.isEmpty()) existing.setYear(Integer.parseInt(yearStr));
        if (!category.isEmpty()) existing.setCategory(category);

        if (bookDAO.update(existing)) {
            System.out.println("Book updated successfully!");
        } else {
            System.out.println("Failed to update book.");
        }
    }

    private static void deleteBook() throws SQLException {
        System.out.println("\n--- Delete Book ---");
        int id = getIntInput("Enter book ID to delete: ");
        if (bookDAO.delete(id)) {
            System.out.println("Book deleted successfully!");
        } else {
            System.out.println("Failed to delete book. It may not exist.");
        }
    }

    private static void searchByCategory() throws SQLException {
        System.out.println("\n--- Search by Category ---");
        String category = getStringInput("Enter category: ");
        List<Book> books = bookDAO.searchByCategory(category);
        if (books.isEmpty()) {
            System.out.println("No books found in category: " + category);
        } else {
            System.out.println("Found " + books.size() + " book(s):");
            for (Book book : books) {
                System.out.println("  " + book);
            }
        }
    }

    private static void searchByYear() throws SQLException {
        System.out.println("\n--- Search by Year ---");
        int year = getIntInput("Enter year: ");
        List<Book> books = bookDAO.searchByYear(year);
        if (books.isEmpty()) {
            System.out.println("No books found for year: " + year);
        } else {
            System.out.println("Found " + books.size() + " book(s):");
            for (Book book : books) {
                System.out.println("  " + book);
            }
        }
    }

    private static void printSummary() throws SQLException {
        System.out.println("\n--- Database Summary ---");
        int total = bookDAO.count();
        System.out.println("Total books: " + total);
        if (total > 0) {
            System.out.println("Database contains data. Use option 1 to view all books.");
        }
    }

    private static String getStringInput(String prompt) {
        System.out.print(prompt);
        return scanner.nextLine().trim();
    }

    private static int getIntInput(String prompt) {
        while (true) {
            try {
                System.out.print(prompt);
                String input = scanner.nextLine().trim();
                return Integer.parseInt(input);
            } catch (NumberFormatException e) {
                System.out.println("Invalid number. Please try again.");
            }
        }
    }
}
