# JDBC Application - Implementation Guide

## Overview

This is a generic JDBC application that demonstrates database operations using SQLite. It follows the **DAO (Data Access Object) Pattern**, making it adaptable to most database-driven applications.

---

## Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                        Main.java                            │
│              (User Interface / Controller)                  │
└─────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────┐
│                        BookDAO.java                         │
│           (Data Access Layer - CRUD Operations)             │
└─────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────┐
│                     DBConnection.java                        │
│              (Database Connection Manager)                  │
└─────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────┐
│                      SQLite Database                        │
│                    (Data Storage Layer)                     │
└─────────────────────────────────────────────────────────────┘
```

### Classes Explained

| Class | Purpose | Key Methods |
|-------|---------|-------------|
| `Book.java` | **Entity/Domain Model** - Represents a single record from the `books` table | Getters/Setters for id, title, author, year, category |
| `BookDAO.java` | **Data Access Object** - Handles all database operations | `insert()`, `selectAll()`, `selectById()`, `update()`, `delete()`, `searchByCategory()`, `searchByYear()`, `insertBatch()`, `count()` |
| `DBConnection.java` | **Connection Manager** - Manages database connections | `getConnection()`, `closeConnection()`, `initializeDatabase()` |
| `Main.java` | **Application Entry Point** - Menu-driven CLI interface | Displays menu, processes user choices |

---

## How to Run (Step-by-Step)

### Method 1: Using Gradle (Recommended)

1. **Install Gradle** (if not already installed)
   ```bash
   # Ubuntu/Debian
   sudo apt install gradle
   
   # Arch Linux
   sudo pacman -S gradle
   
   # macOS
   brew install gradle
   ```

2. **Build the project**
   ```bash
   cd /data/wa/jdbc-app
   gradle build
   ```

3. **Run the application**
   ```bash
   gradle run
   ```

### Method 2: Manual Compilation and Execution

1. **Download SQLite JDBC Driver manually**
   ```bash
   # Download from: https://github.com/xerial/sqlite-jdbc/releases
   wget https://github.com/xerial/sqlite-jdbc/releases/download/v3.46.1.0/sqlite-jdbc-3.46.1.0.jar -O sqlite-jdbc.jar
   ```

2. **Compile the Java files**
   ```bash
   cd /data/wa/jdbc-app/src
   javac -cp ".:../sqlite-jdbc.jar" com/example/*.java
   ```

3. **Run the application**
   ```bash
   java -cp ".:../sqlite-jdbc.jar" com.example.Main
   ```

### Method 3: Create JAR and Run

1. **Compile with Gradle**
   ```bash
   gradle jar
   ```

2. **Run the JAR**
   ```bash
   java -jar build/libs/jdbc-app-1.0.0.jar
   ```

---

## Basic Logic Flow

### 1. Application Startup (`Main.main()`)
```
1. Initialize database (creates tables if not exist)
2. Display main menu
3. Loop until user chooses "Exit"
4. Process user selection
5. Handle database errors gracefully
6. Cleanup on exit
```

### 2. Database Operations (`BookDAO`)
Each method follows this pattern:
```
1. Get connection from DBConnection
2. Prepare SQL statement (try-with-resources)
3. Execute query/update
4. Process results
5. Return data or status
```

### 3. Connection Management (`DBConnection`)
```
1. Check if connection exists and is open
2. If not, create new connection to SQLite
3. Return connection for use
4. Close when application exits
```

---

## Adapting This Template for Other Projects

### Step 1: Change the Entity Class
```java
// Example: Product instead of Book
public class Product {
    private int id;
    private String name;
    private double price;
    private int stock;
    // ... getters/setters
}
```

### Step 2: Update the DAO
```java
public class ProductDAO {
    public int insert(Product p) throws SQLException {
        String sql = "INSERT INTO products(name, price, stock) VALUES(?,?,?)";
        // ... rest follows same pattern
    }
    
    public List<Product> selectAll() throws SQLException { ... }
    // Add methods specific to your needs
}
```

### Step 3: Update DBConnection (if different database)
```java
// For MySQL
private static final String DB_URL = "jdbc:mysql://localhost:3306/mydb";
// Driver: com.mysql.cj.jdbc.Driver

// For PostgreSQL  
private static final String DB_URL = "jdbc:postgresql://localhost:5432/mydb";
// Driver: org.postgresql.Driver
```

### Step 4: Update Main Menu
```java
// Change options to match your domain
case 1: listAllProducts(); break;
case 2: viewProductById(); break;
case 3: addNewProduct(); break;
// etc.
```

---

## SQL Schema to Create

The `books` table is created automatically, but here's the SQL if you need to create it manually:

```sql
CREATE TABLE IF NOT EXISTS books (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT NOT NULL,
    author TEXT NOT NULL,
    year INTEGER,
    category TEXT
);
```

For a `products` table:
```sql
CREATE TABLE IF NOT EXISTS products (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    price REAL NOT NULL,
    stock INTEGER DEFAULT 0
);
```

---

## Key JDBC Concepts Demonstrated

| Concept | Example in Code |
|---------|-----------------|
| **Driver Loading** | `Class.forName("org.sqlite.JDBC")` |
| **Connection** | `DriverManager.getConnection(DB_URL)` |
| **PreparedStatement** | `conn.prepareStatement(sql)` - prevents SQL injection |
| **Try-with-resources** | Automatic `close()` of Connection/Statement/ResultSet |
| **Transaction Management** | `conn.setAutoCommit(false)` for batch operations |
| **Generated Keys** | `Statement.RETURN_GENERATED_KEYS` for new record IDs |
| **ResultSet Mapping** | `mapResultSetToBook()` converts rows to objects |

---

## Troubleshooting

| Issue | Solution |
|-------|----------|
| `ClassNotFoundException: org.sqlite.JDBC` | Ensure SQLite JDBC JAR is in classpath |
| `SQLException: database is locked` | Close previous connections, use single connection |
| `No suitable driver found` | Check JDBC URL format and driver JAR |
| `Table doesn't exist` | Run `initializeDatabase()` first or create table manually |

---

## Files Modified for Customization

When adapting this template, you'll typically modify:
1. `src/com/example/Book.java` → Your entity class
2. `src/com/example/BookDAO.java` → Your DAO class
3. `src/com/example/Main.java` → Your UI/controller
4. `build.gradle` → Update dependencies if needed
5. `DBConnection.java` → Change database settings if needed

---

## Summary

This application demonstrates a **layered architecture** with:
- **Presentation Layer**: `Main.java` (CLI menu)
- **Business/Data Layer**: `BookDAO.java` (CRUD operations)
- **Data Access Layer**: `DBConnection.java` (connection management)
- **Data Storage**: SQLite database

The DAO pattern decouples the application from the database implementation, making it easy to swap databases or modify queries without affecting the UI layer.
