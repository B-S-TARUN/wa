# JDBC Application Example

A generic, standalone JDBC application demonstrating database operations using SQLite. This project serves as a template that can be adapted for most database-driven applications.

## Features

- **CRUD Operations**: Create, Read, Update, Delete functionality
- **Search Capabilities**: Query by category and year
- **Batch Insert**: Efficiently insert multiple records at once
- **Connection Management**: Centralized database connection handling
- **Resource Management**: Proper use of try-with-resources for automatic cleanup
- **Menu-Driven UI**: Interactive command-line interface

## Project Structure

```
jdbc-app/
├── src/
│   └── com/example/
│       ├── Main.java       # Application entry point with UI
│       ├── Book.java       # Entity/Domain class
│       ├── BookDAO.java    # Data Access Object (CRUD operations)
│       └── DBConnection.java  # Database connection management
├── build.gradle            # Gradle build configuration
└── README.md               # This file
```

## Requirements

- Java 17 or higher
- Gradle 7.0 or higher (included via Gradle Wrapper)

## Building and Running

### Using Gradle (Recommended)

```bash
# Build the project
gradle build

# Run the application
gradle run

# Build a standalone JAR
gradle jar
java -jar build/libs/jdbc-app-1.0.0.jar
```

### Manual Compilation

```bash
# Compile
javac -d out src/com/example/*.java

# Run
java -cp out com.example.Main
```

## Database Configuration

The application uses SQLite by default:

- **Database File**: `jdbc.db` (created in the working directory)
- **Driver**: `org.sqlite.JDBC`

### Switching to Another Database

To use MySQL, PostgreSQL, or another JDBC-compatible database:

1. Update `DBConnection.java`:
   - Change the JDBC URL format
   - Update the driver class name
   - Add the appropriate driver dependency to `build.gradle`

2. Example for MySQL:
   ```java
   private static final String DB_URL = "jdbc:mysql://localhost:3306/mydb";
   // Driver: com.mysql.cj.jdbc.Driver
   // Dependency: mysql:mysql-connector-java
   ```

## BookDAO Methods

| Method | Description |
|--------|-------------|
| `insert(Book)` | Add a new book, returns generated ID |
| `selectAll()` | Retrieve all books |
| `selectById(int)` | Find a book by ID |
| `update(Book)` | Modify an existing book |
| `delete(int)` | Remove a book by ID |
| `searchByCategory(String)` | Find books by category |
| `searchByYear(int)` | Find books by year |
| `insertBatch(List)` | Bulk insert multiple books |
| `count()` | Get total book count |

## Generic Pattern for Other Projects

This example follows the **DAO Pattern** which is applicable to most database applications:

1. **Entity Class** (`Book.java`): Represents table rows
2. **DAO Class** (`BookDAO.java`): Encapsulates data access logic
3. **Connection Manager** (`DBConnection.java`): Handles database connections
4. **Main Application**: Business logic and user interaction

To adapt for another domain (e.g., `Product`, `User`, `Order`):
- Copy and rename the entity and DAO files
- Update SQL queries for your table schema
- Modify the UI to match your use case

## Best Practices Demonstrated

- Use of `PreparedStatement` to prevent SQL injection
- Try-with-resources for automatic resource disposal
- Transaction management for batch operations
- Separation of concerns (entity, DAO, UI)
- Proper exception handling
- Connection pooling preparation (single connection for this example)

## License

This is an educational example, free to use and modify.
