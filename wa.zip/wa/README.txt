=================================================================
NETWORK PROGRAMMING LAB - JAVA PROGRAMS (Windows)
=================================================================
All programs are simple, console-based, and run on any JDK 8+.

HOW TO COMPILE & RUN (Windows cmd)
-----------------------------------------------------------------
  javac FileName.java       -> compile
  java  ClassName           -> run

(Java 11+ allows:  java FileName.java  directly.)

-----------------------------------------------------------------
FILE LIST
-----------------------------------------------------------------
Experiment2_Network_Commands.txt
    Guide for NETSTAT, NSLOOKUP, TRACERT, ARP, IPCONFIG with
    usage, purpose (need) and sample outputs. Type the commands
    directly in cmd.

Experiment3_HostNameIP.java
    Identifies machine's host name and IP address.
    Run:  java Exp3_HostNameIP

Experiment4_NextHopRouter.java
    Finds default gateway IP (from route print) and its MAC
    address (from arp -a).
    Run:  java Exp4_NextHopRouter

Experiment5_PortScanner.java
    Scans ports on localhost and prints which are OPEN/in use.
    Run:  java Exp5_PortScanner 1 1024

Experiment6_DNSResolver.java
    Shows local DNS servers (ipconfig /all) and resolves a host
    name using JNDI DNS + InetAddress.
    Run:  java Exp6_DNSResolver www.google.com

Experiment7_TCPServer.java  +  Exp7_TCPClient.java
    Simple TCP chat client/server.
    Window 1:  java Exp7_TCPServer
    Window 2:  java Exp7_TCPClient

Experiment7b:  Exp7b_TimeServer.java  +  Exp7b_TimeClient.java
    Time server: sends current date/time on connect.
    Window 1:  java Exp7b_TimeServer
    Window 2:  java Exp7b_TimeClient

Experiment8a:  Exp8a_EchoServer.java  +  Exp8a_EchoClient.java
    UDP ECHO server/client.
    Window 1:  java Exp8a_EchoServer
    Window 2:  java Exp8a_EchoClient

Experiment8b_Ping.java
    PING simulation using isReachable with 4 packets + stats.
    Run:  java Exp8b_Ping www.google.com

Experiment8c:  Exp8c_UDPTimeServer.java  +  Exp8c_UDPTimeClient.java
    UDP time server/client.
    Window 1:  java Exp8c_UDPTimeServer
    Window 2:  java Exp8c_UDPTimeClient

Experiment9:  Exp9_TCPFileServer.java  +  Exp9_TCPFileClient.java
    File transfer over TCP (client sends file to server).
    Window 1:  java Exp9_TCPFileServer
    Window 2:  java Exp9_TCPFileClient test.txt

Experiment10:  Exp10_UDPFileServer.java  +  Exp10_UDPFileClient.java
    File transfer over UDP with sequence numbers per packet.
    Window 1:  java Exp10_UDPFileServer
    Window 2:  java Exp10_UDPFileClient test.txt

Experiment11_Addition.java + Exp11_RMIClient.java
    RMI: remote object adds two numbers on the server.
    Step 1:  javac Exp11_Addition.java Exp11_RMIClient.java
    Step 2:  start rmiregistry        (keep this window open)
    Step 3:  java Exp11_Addition      (server window)
    Step 4:  java Exp11_RMIClient     (client window)

-----------------------------------------------------------------
NOTES FOR WINDOWS
-----------------------------------------------------------------
- "localhost" = 127.0.0.1. Servers must be started BEFORE clients.
- If a port is already in use, change the port number in both
  server and client (same number!).
- First time you run a server, Windows Firewall may show a popup;
  click "Allow access" (private networks).
- For Exp9/Exp10, a sample test.txt is included in this folder.
- All compiled with: javac *.java  (verified, 0 errors)
