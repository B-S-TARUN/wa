// ================================================================
// EXPERIMENT 7b : TIME CLIENT (TCP)
// ================================================================
// Connects to the time server and displays the date & time.
// Run:  java Exp7b_TimeClient   (after starting the server)
// ================================================================
import java.io.*;
import java.net.*;

public class Exp7b_TimeClient {
    public static void main(String[] args) throws Exception {
        Socket s = new Socket("localhost", 6000);
        BufferedReader in = new BufferedReader(
                new InputStreamReader(s.getInputStream()));
        System.out.println("Server date & time : " + in.readLine());
        s.close();
    }
}
