// ================================================================
// EXPERIMENT 7b : TIME SERVER (TCP)
// ================================================================
// Sends the current date & time to any client that connects
// on port 6000.
// Run:  java Exp7b_TimeServer   (start BEFORE the client)
// ================================================================
import java.io.*;
import java.net.*;
import java.util.Date;

public class Exp7b_TimeServer {
    public static void main(String[] args) throws Exception {
        ServerSocket ss = new ServerSocket(6000);
        System.out.println("Time Server listening on port 6000...");

        while (true) {                                // serve many clients
            Socket s = ss.accept();
            System.out.println("Client connected: " + s.getInetAddress());
            PrintWriter out = new PrintWriter(s.getOutputStream(), true);
            out.println(new Date());                  // send date & time
            s.close();                                // done with this client
        }
    }
}
