# Implementation Guide - Question 4: Book Issue Form (HTML, CSS, JS with JSP Validation)

## How to Run

### Prerequisites
- Java Development Kit (JDK) installed
- Apache Tomcat server (version 9 or higher)

### Setup Steps

1. **Create a folder** named `book-issue-form-jsp`
2. **Create three files** inside:
   - `index.jsp`
   - `styles.css`
   - `script.js`

3. **Deploy to Tomcat**:
   - Copy your project folder to `Tomcat/webapps/` directory
   - Or use your IDE (Eclipse/IntelliJ) to run on Tomcat

4. **Start Tomcat**:
   - Run `Tomcat/bin/startup.sh` (Linux/Mac) or `startup.bat` (Windows)
   - Default URL: `http://localhost:8080/book-issue-form-jsp/index.jsp`

5. **Open in browser** - Navigate to the URL above

### Quick Test (without Tomcat)
For testing HTML/CSS/JS only, open `index.html` in browser - client-side validation will work, server-side JSP validation runs only when deployed.

---

## Basic Logic

### 1. JSP Scriptlet (Server-Side)
- Located at top of `index.jsp` inside `<% %>`
- Runs on server BEFORE page renders
- Gets form parameters with `request.getParameter()`
- Uses Java's LocalDate API for date validation
- Sets error messages as request attributes
- Sets success message when all validations pass

### 2. JavaScript Validation (Client-Side)
- Runs in browser for instant feedback
- Validates on blur (leaving field) + on submit
- Same rules as JSP but expressed in JavaScript

### 3. Error Display
- JSP uses `${requestScope.studentIdError}` to show server errors
- JavaScript shows errors via `showError()` function

### 4. Flow
1. User fills form → clicks submit
2. JavaScript validates first (client-side)
3. If JS fails → shows errors, form doesn't submit
4. If JS passes → submits to server
5. JSP validates again (server-side protection)
6. If JSP fails → re-renders form with errors
7. If JSP passes → shows success message

---

## What to Change for Similar Questions

### To add a new field
JSP - add to scriptlet:
```jsp
String newField = request.getParameter("newField");
String newFieldError = "";
if (newField == null || newField.trim().equals("")) {
    newFieldError = "New field is required";
}
if (!newFieldError.equals("")) {
    request.setAttribute("newFieldError", newFieldError);
}
```

HTML - add field:
```jsp
<input type="text" id="newField" name="newField" value="<%= newField != null ? newField : "" %>">
<span class="error"><%= request.getAttribute("newFieldError") != null ? request.getAttribute("newFieldError") : "" %></span>
```

### To change validation rules
Example - Student ID must be exactly 6 digits:
```jsp
if (!studentId.matches("^\\d{6}$")) {
    studentIdError = "Student ID must be exactly 6 digits";
}
```

### To connect to database
Replace success message with database insert:
```jsp
if (studentIdError.equals("") && bookNameError.equals("") && issueDateError.equals("")) {
    // Connect to database and insert record
    // Example with JDBC:
    // Connection conn = DriverManager.getConnection(DB_URL);
    // PreparedStatement stmt = conn.prepareStatement("INSERT INTO book_issues VALUES (?, ?, ?)");
    // stmt.setString(1, studentId);
    // stmt.setString(2, bookName);
    // stmt.setString(3, issueDate);
    // stmt.executeUpdate();
    
    success = "Book issued successfully!";
    request.setAttribute("success", success);
}
```

### To add return date field
Add in JSP scriptlet:
```jsp
String returnDate = request.getParameter("returnDate");
String returnDateError = "";
if (returnDate != null && !returnDate.equals("")) {
    LocalDate retDate = LocalDate.parse(returnDate);
    LocalDate issueDateParsed = LocalDate.parse(issueDate);
    if (retDate.isBefore(issueDateParsed)) {
        returnDateError = "Return date must be after issue date";
    }
}
// Add to error check
if (!returnDateError.equals("")) {
    request.setAttribute("returnDateError", returnDateError);
} else {
    // Include in success
}
```

### To change error message style
Modify in `styles.css`:
```css
.error {
    color: #e74c3c;
    font-size: 12px;
    font-weight: bold;
    display: block;
    margin-top: 5px;
    padding: 5px;
    background: #fde8e8;
    border-radius: 4px;
}
```

### For different application servers
- **Jetty**: Similar deployment to webapps/ directory
- **WildFly/JBoss**: Deploy to deployments/ directory
- **Embedded Jetty (programmatic)**: Use embedded Jetty with Java main class