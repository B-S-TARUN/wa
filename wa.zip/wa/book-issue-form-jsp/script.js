const form = document.getElementById('issueForm');
const studentId = document.getElementById('studentId');
const bookName = document.getElementById('bookName');
const issueDate = document.getElementById('issueDate');

function showError(input, message) {
    let errorSpan = input.nextElementSibling;
    if (errorSpan && errorSpan.classList.contains('error')) {
        errorSpan.textContent = message;
    }
}

function clearError(input) {
    let errorSpan = input.nextElementSibling;
    if (errorSpan && errorSpan.classList.contains('error')) {
        errorSpan.textContent = '';
    }
}

function validateStudentId() {
    const value = studentId.value.trim();
    if (value === '') {
        showError(studentId, 'Student ID is required');
        return false;
    }
    if (!/^[A-Za-z0-9]{4,10}$/.test(value)) {
        showError(studentId, 'Student ID must be 4-10 alphanumeric characters');
        return false;
    }
    clearError(studentId);
    return true;
}

function validateBookName() {
    const value = bookName.value.trim();
    if (value === '') {
        showError(bookName, 'Book Name is required');
        return false;
    }
    if (value.length < 2) {
        showError(bookName, 'Book Name must be at least 2 characters');
        return false;
    }
    clearError(bookName);
    return true;
}

function validateIssueDate() {
    const value = issueDate.value;
    if (value === '') {
        showError(issueDate, 'Issue Date is required');
        return false;
    }
    const selectedDate = new Date(value);
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    if (selectedDate < today) {
        showError(issueDate, 'Issue Date cannot be in the past');
        return false;
    }
    clearError(issueDate);
    return true;
}

studentId.addEventListener('blur', validateStudentId);
bookName.addEventListener('blur', validateBookName);
issueDate.addEventListener('blur', validateIssueDate);

form.addEventListener('submit', (e) => {
    const isStudentIdValid = validateStudentId();
    const isBookNameValid = validateBookName();
    const isIssueDateValid = validateIssueDate();

    if (!isStudentIdValid || !isBookNameValid || !isIssueDateValid) {
        e.preventDefault();
    }
});