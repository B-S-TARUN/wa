<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="java.time.LocalDate" %>
<%
    String studentId = request.getParameter("studentId");
    String bookName = request.getParameter("bookName");
    String issueDate = request.getParameter("issueDate");
    String success = null;

    if (studentId != null && bookName != null && issueDate != null) {
        String studentIdError = "";
        String bookNameError = "";
        String issueDateError = "";

        // Validate Student ID
        if (studentId == null || studentId.trim().equals("")) {
            studentIdError = "Student ID is required";
        } else if (!studentId.matches("^[A-Za-z0-9]{4,10}$")) {
            studentIdError = "Student ID must be 4-10 alphanumeric characters";
        }

        // Validate Book Name
        if (bookName == null || bookName.trim().equals("")) {
            bookNameError = "Book Name is required";
        } else if (bookName.trim().length() < 2) {
            bookNameError = "Book Name must be at least 2 characters";
        }

        // Validate Issue Date
        if (issueDate == null || issueDate.equals("")) {
            issueDateError = "Issue Date is required";
        } else {
            try {
                LocalDate selected = LocalDate.parse(issueDate);
                LocalDate today = LocalDate.now();
                if (selected.isBefore(today)) {
                    issueDateError = "Issue Date cannot be in the past";
                }
            } catch (Exception e) {
                issueDateError = "Invalid date format";
            }
        }

        // If no errors, set success message
        if (studentIdError.equals("") && bookNameError.equals("") && issueDateError.equals("")) {
            success = "Book issued successfully!\nStudent ID: " + studentId + "\nBook: " + bookName + "\nDate: " + issueDate;
            request.setAttribute("success", success);
        } else {
            request.setAttribute("studentIdError", studentIdError);
            request.setAttribute("bookNameError", bookNameError);
            request.setAttribute("issueDateError", issueDateError);
        }
    }
%>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Book Issue Form</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>

    <div class="form-container">
        <h1>Book Issue Form</h1>
        
        <form id="issueForm" method="post">
            <div class="form-group">
                <label for="studentId">Student ID</label>
                <input type="text" id="studentId" name="studentId" value="<%= studentId != null ? studentId : "" %>" placeholder="Enter Student ID">
                <span class="error"><%= request.getAttribute("studentIdError") != null ? request.getAttribute("studentIdError") : "" %></span>
            </div>

            <div class="form-group">
                <label for="bookName">Book Name</label>
                <input type="text" id="bookName" name="bookName" value="<%= bookName != null ? bookName : "" %>" placeholder="Enter Book Name">
                <span class="error"><%= request.getAttribute("bookNameError") != null ? request.getAttribute("bookNameError") : "" %></span>
            </div>

            <div class="form-group">
                <label for="issueDate">Issue Date</label>
                <input type="date" id="issueDate" name="issueDate" value="<%= issueDate != null ? issueDate : "" %>">
                <span class="error"><%= request.getAttribute("issueDateError") != null ? request.getAttribute("issueDateError") : "" %></span>
            </div>

            <button type="submit">Issue Book</button>
        </form>

        <% if (success != null) { %>
            <div class="success"><%= success.replace("\n", "<br>") %></div>
        <% } %>
    </div>

</body>
</html>