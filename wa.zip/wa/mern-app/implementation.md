# Implementation Guide - Question 4: Book Issue Form (MERN Stack)

## Prerequisites
- Node.js installed (v14 or higher)
- MongoDB installed and running locally
- Code editor (VS Code recommended)

---

## How to Run

### Step 1: Start MongoDB
```bash
# Windows
mongod

# Linux/Mac
sudo mongod
```
Or use MongoDB Compass and connect to local instance.

### Step 2: Set up Backend
```bash
cd mern-app/backend
npm install
npm start
```
Backend runs on http://localhost:5000

### Step 3: Set up Frontend
```bash
cd mern-app/frontend
npm install
npm start
```
Frontend opens at http://localhost:3000

That's it! Form submits to MongoDB database.

---

## Basic Logic

### Backend (Express + MongoDB)

#### 1. server.js
- Express server on port 5000
- Connects to MongoDB using Mongoose
- Routes all `/api/book-issues` requests to bookIssueRoutes

#### 2. Model (models/BookIssue.js)
- Mongoose schema with fields: studentId, bookName, issueDate, createdAt
- All fields required

#### 3. Controller (controllers/bookIssueController.js)
- **createBookIssue**: Validates + saves to MongoDB
- **getAllBookIssues**: Returns all records sorted by date
- **getBookIssueById**: Returns single record
- **updateBookIssue**: Updates record
- **deleteBookIssue**: Deletes record

#### 4. Routes (routes/bookIssueRoutes.js)
- POST / - Create
- GET / - Read all
- GET /:id - Read one
- PUT /:id - Update
- DELETE /:id - Delete

### Frontend (React)

#### 1. App.js (Main Component)
- **State**: formData, errors, bookIssues, loading
- **useEffect**: Fetches book issues on load
- **validate()**: Client-side validation (same as backend rules)
- **handleSubmit()**: POST to API
- **handleDelete()**: DELETE to API

#### 2. API Calls
- All using fetch() to http://localhost:5000/api/book-issues
- JSON for request/response

---

## What to Change for Similar Questions

### To add a new field

Backend - Model (models/BookIssue.js):
```javascript
const bookIssueSchema = new mongoose.Schema({
    // existing fields...
    newField: {
        type: String,
        required: true,
        trim: true
    }
});
```

Backend - Controller:
```javascript
const { studentId, bookName, issueDate, newField } = req.body;
// Add validation for newField
if (!newField) {
    errors.newField = 'New field is required';
}
// In create, include newField
const newBookIssue = new BookIssue({
    studentId, bookName, issueDate, newField
});
```

Frontend - App.js:
```javascript
const [formData, setFormData] = useState({
    studentId: '',
    bookName: '',
    issueDate: '',
    newField: ''  // Add here
});

// Add in JSX
<div className="form-group">
    <label>New Field</label>
    <input
        type="text"
        name="newField"
        value={formData.newField}
        onChange={handleChange}
    />
    {errors.newField && <span className="error">{errors.newField}</span>}
</div>
```

### To change database connection
Modify in backend/.env:
```env
PORT=5000
MONGO_URI=mongodb://localhost:27017/your_database_name
```

Or use MongoDB Atlas:
```env
MONGO_URI=mongodb+srv://<username>:<password>@cluster.mongodb.net/your_db
```

### To add authentication
Backend - Add auth middleware:
```bash
npm install jsonwebtoken bcryptjs
```

Create auth controller and middleware, then protect routes:
```javascript
const authenticate = require('../middleware/auth');
router.post('/', authenticate, createBookIssue);
```

Frontend - Add token to headers:
```javascript
const response = await fetch(API_URL, {
    method: 'POST',
    headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`
    },
    body: JSON.stringify(formData)
});
```

### To use different frontend (Vite instead of CRA)
```bash
npm create vite@latest frontend -- --template react
cd frontend
npm install
npm run dev
```
Then copy src/App.js and src/index.css into the Vite project.

### To add update functionality
Frontend - Add state for editing:
```javascript
const [editingId, setEditingId] = useState(null);

const handleEdit = (issue) => {
    setEditingId(issue._id);
    setFormData({
        studentId: issue.studentId,
        bookName: issue.bookName,
        issueDate: issue.issueDate.split('T')[0]
    });
};

const handleSubmit = async (e) => {
    e.preventDefault();
    const url = editingId ? `${API_URL}/${editingId}` : API_URL;
    const method = editingId ? 'PUT' : 'POST';
    // ... rest of code
};
```

### To add pagination
Backend - Update controller:
```javascript
const getAllBookIssues = async (req, res) => {
    const page = parseInt(req.query.page) || 1;
    const limit = 10;
    const skip = (page - 1) * limit;
    
    const bookIssues = await BookIssue.find()
        .sort({ createdAt: -1 })
        .skip(skip)
        .limit(limit);
    
    const total = await BookIssue.countDocuments();
    res.json({ data: bookIssues, total, page, pages: Math.ceil(total / limit) });
};
```

### To deploy to production
Backend:
```bash
cd backend
npm run build
# Deploy to Render, Railway, or Heroku
```

Frontend:
```bash
cd frontend
npm run build
# Build output in frontend/build - deploy to Netlify, Vercel
```

### To switch to different database (PostgreSQL, MySQL)
Replace Mongoose with Sequelize or pg:
```bash
npm install pg sequelize
```
Then update model and controller to use SQL queries.