import { useState, useEffect } from 'react';

function App() {
    const [bookIssues, setBookIssues] = useState([]);
    const [formData, setFormData] = useState({
        studentId: '',
        bookName: '',
        issueDate: ''
    });
    const [errors, setErrors] = useState({});
    const [success, setSuccess] = useState('');
    const [loading, setLoading] = useState(false);

    const API_URL = 'http://localhost:5000/api/book-issues';

    useEffect(() => {
        fetchBookIssues();
    }, []);

    const fetchBookIssues = async () => {
        try {
            const response = await fetch(API_URL);
            const data = await response.json();
            setBookIssues(data);
        } catch (error) {
            console.error('Error fetching:', error);
        }
    };

    const handleChange = (e) => {
        setFormData({ ...formData, [e.target.name]: e.target.value });
        if (errors[e.target.name]) {
            setErrors({ ...errors, [e.target.name]: '' });
        }
    };

    const validate = () => {
        const newErrors = {};
        const { studentId, bookName, issueDate } = formData;

        if (!studentId || studentId.trim() === '') {
            newErrors.studentId = 'Student ID is required';
        } else if (!/^[A-Za-z0-9]{4,10}$/.test(studentId)) {
            newErrors.studentId = 'Student ID must be 4-10 alphanumeric characters';
        }

        if (!bookName || bookName.trim() === '') {
            newErrors.bookName = 'Book Name is required';
        } else if (bookName.trim().length < 2) {
            newErrors.bookName = 'Book Name must be at least 2 characters';
        }

        if (!issueDate) {
            newErrors.issueDate = 'Issue Date is required';
        } else {
            const selectedDate = new Date(issueDate);
            const today = new Date();
            today.setHours(0, 0, 0, 0);
            if (selectedDate < today) {
                newErrors.issueDate = 'Issue Date cannot be in the past';
            }
        }

        setErrors(newErrors);
        return Object.keys(newErrors).length === 0;
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        setSuccess('');
        setLoading(true);

        if (!validate()) {
            setLoading(false);
            return;
        }

        try {
            const response = await fetch(API_URL, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(formData)
            });

            const data = await response.json();

            if (response.ok) {
                setSuccess('Book issued successfully!');
                setFormData({ studentId: '', bookName: '', issueDate: '' });
                fetchBookIssues();
            } else if (data.errors) {
                setErrors(data.errors);
            } else {
                setErrors({ submit: data.message || 'Error submitting form' });
            }
        } catch (error) {
            setErrors({ submit: 'Server error. Please try again.' });
        }

        setLoading(false);
    };

    const handleDelete = async (id) => {
        if (!window.confirm('Are you sure you want to delete?')) return;
        
        try {
            const response = await fetch(`${API_URL}/${id}`, {
                method: 'DELETE'
            });
            if (response.ok) {
                fetchBookIssues();
            }
        } catch (error) {
            console.error('Delete error:', error);
        }
    };

    return (
        <div className="container">
            <h1>Book Issue Form - MERN</h1>

            <form onSubmit={handleSubmit} className="form">
                <div className="form-group">
                    <label>Student ID</label>
                    <input
                        type="text"
                        name="studentId"
                        value={formData.studentId}
                        onChange={handleChange}
                        placeholder="Enter Student ID"
                    />
                    {errors.studentId && <span className="error">{errors.studentId}</span>}
                </div>

                <div className="form-group">
                    <label>Book Name</label>
                    <input
                        type="text"
                        name="bookName"
                        value={formData.bookName}
                        onChange={handleChange}
                        placeholder="Enter Book Name"
                    />
                    {errors.bookName && <span className="error">{errors.bookName}</span>}
                </div>

                <div className="form-group">
                    <label>Issue Date</label>
                    <input
                        type="date"
                        name="issueDate"
                        value={formData.issueDate}
                        onChange={handleChange}
                    />
                    {errors.issueDate && <span className="error">{errors.issueDate}</span>}
                </div>

                {errors.submit && <div className="error-server">{errors.submit}</div>}

                <button type="submit" disabled={loading}>
                    {loading ? 'Submitting...' : 'Issue Book'}
                </button>
            </form>

            {success && <div className="success">{success}</div>}

            <div className="list-section">
                <h2>Issued Books</h2>
                {bookIssues.length === 0 ? (
                    <p>No books issued yet.</p>
                ) : (
                    <table>
                        <thead>
                            <tr>
                                <th>Student ID</th>
                                <th>Book Name</th>
                                <th>Issue Date</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            {bookIssues.map((issue) => (
                                <tr key={issue._id}>
                                    <td>{issue.studentId}</td>
                                    <td>{issue.bookName}</td>
                                    <td>{new Date(issue.issueDate).toLocaleDateString()}</td>
                                    <td>
                                        <button
                                            onClick={() => handleDelete(issue._id)}
                                            className="delete-btn"
                                        >
                                            Delete
                                        </button>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                )}
            </div>
        </div>
    );
}

export default App;