const express = require('express');
const router = express.Router();
const {
    createBookIssue,
    getAllBookIssues,
    getBookIssueById,
    updateBookIssue,
    deleteBookIssue
} = require('../controllers/bookIssueController');

router.post('/', createBookIssue);
router.get('/', getAllBookIssues);
router.get('/:id', getBookIssueById);
router.put('/:id', updateBookIssue);
router.delete('/:id', deleteBookIssue);

module.exports = router;