const BookIssue = require('../models/BookIssue');

const createBookIssue = async (req, res) => {
    try {
        const { studentId, bookName, issueDate } = req.body;

        const errors = {};
        if (!studentId || studentId.trim() === '') {
            errors.studentId = 'Student ID is required';
        } else if (!/^[A-Za-z0-9]{4,10}$/.test(studentId)) {
            errors.studentId = 'Student ID must be 4-10 alphanumeric characters';
        }

        if (!bookName || bookName.trim() === '') {
            errors.bookName = 'Book Name is required';
        } else if (bookName.trim().length < 2) {
            errors.bookName = 'Book Name must be at least 2 characters';
        }

        if (!issueDate) {
            errors.issueDate = 'Issue Date is required';
        } else {
            const selectedDate = new Date(issueDate);
            const today = new Date();
            today.setHours(0, 0, 0, 0);
            if (selectedDate < today) {
                errors.issueDate = 'Issue Date cannot be in the past';
            }
        }

        if (Object.keys(errors).length > 0) {
            return res.status(400).json({ errors });
        }

        const newBookIssue = new BookIssue({
            studentId: studentId.trim(),
            bookName: bookName.trim(),
            issueDate
        });

        const saved = await newBookIssue.save();
        res.status(201).json(saved);

    } catch (error) {
        res.status(500).json({ message: 'Server error', error: error.message });
    }
};

const getAllBookIssues = async (req, res) => {
    try {
        const bookIssues = await BookIssue.find().sort({ createdAt: -1 });
        res.json(bookIssues);
    } catch (error) {
        res.status(500).json({ message: 'Server error', error: error.message });
    }
};

const getBookIssueById = async (req, res) => {
    try {
        const bookIssue = await BookIssue.findById(req.params.id);
        if (!bookIssue) {
            return res.status(404).json({ message: 'Book issue not found' });
        }
        res.json(bookIssue);
    } catch (error) {
        res.status(500).json({ message: 'Server error', error: error.message });
    }
};

const updateBookIssue = async (req, res) => {
    try {
        const { studentId, bookName, issueDate } = req.body;
        const bookIssue = await BookIssue.findById(req.params.id);

        if (!bookIssue) {
            return res.status(404).json({ message: 'Book issue not found' });
        }

        if (studentId) bookIssue.studentId = studentId;
        if (bookName) bookIssue.bookName = bookName;
        if (issueDate) bookIssue.issueDate = issueDate;

        const updated = await bookIssue.save();
        res.json(updated);
    } catch (error) {
        res.status(500).json({ message: 'Server error', error: error.message });
    }
};

const deleteBookIssue = async (req, res) => {
    try {
        const bookIssue = await BookIssue.findByIdAndDelete(req.params.id);
        if (!bookIssue) {
            return res.status(404).json({ message: 'Book issue not found' });
        }
        res.json({ message: 'Book issue deleted successfully' });
    } catch (error) {
        res.status(500).json({ message: 'Server error', error: error.message });
    }
};

module.exports = {
    createBookIssue,
    getAllBookIssues,
    getBookIssueById,
    updateBookIssue,
    deleteBookIssue
};