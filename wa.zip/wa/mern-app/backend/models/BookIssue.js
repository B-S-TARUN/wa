const mongoose = require('mongoose');

const bookIssueSchema = new mongoose.Schema({
    studentId: {
        type: String,
        required: true,
        trim: true
    },
    bookName: {
        type: String,
        required: true,
        trim: true
    },
    issueDate: {
        type: Date,
        required: true
    },
    createdAt: {
        type: Date,
        default: Date.now
    }
});

module.exports = mongoose.model('BookIssue', bookIssueSchema);