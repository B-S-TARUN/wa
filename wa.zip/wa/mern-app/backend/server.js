const express = require('express');
const cors = require('cors');
const mongoose = require('mongoose');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 5000;

app.use(cors());
app.use(express.json());

const uri = process.env.MONGO_URI || 'mongodb://localhost:27017/bookissue';

mongoose.connect(uri)
    .then(() => console.log('MongoDB connected'))
    .catch(err => console.log('MongoDB connection error:', err));

const bookIssueRoutes = require('./routes/bookIssueRoutes');
app.use('/api/book-issues', bookIssueRoutes);

app.get('/', (req, res) => {
    res.send('Book Issue API is running');
});

app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
});