// ================================================================
// EXPERIMENT 3 : Identify the machine's Host Name and IP Address
// ================================================================
import java.net.*;

public class Exp3_HostNameIP {
    public static void main(String[] args) throws Exception {
        InetAddress addr = InetAddress.getLocalHost();

        System.out.println("Host Name        : " + addr.getHostName());
        System.out.println("IP Address       : " + addr.getHostAddress());
        System.out.println("Fully Qual. Name : " + addr.getCanonicalHostName());
        System.out.println("Loopback Address : " + InetAddress.getLoopbackAddress().getHostAddress());
        System.out.println("Reachable google.com ? " +
                InetAddress.getByName("www.google.com").isReachable(5000));
    }
}
