# Implementation Guide - Question 2: Image Gallery (React)

## How to Run

1. **Create a folder** named `image-gallery-react`
2. **Create three files** inside:
   - `index.html`
   - `styles.css`
   - `App.jsx`
3. **Copy the code** from the respective files above into each file
4. **Open index.html** in any web browser

That's it! Uses React via CDN - no build tools required.

---

## Basic Logic

### 1. HTML Structure
- Loads React, ReactDOM, and Babel from CDN
- Has a `<div id="root">` where React renders the app
- Includes Babel to transpile JSX in the browser

### 2. React Component (App.jsx)
- **useState hook**: Manages `currentIndex` - which image is shown in lightbox (null = closed)
- **images array**: List of image objects with `src` and `name`
- **return statement**: Renders gallery grid + conditional lightbox

### 3. Conditional Rendering
- Gallery: Maps through images array, creates `<img>` for each
- Lightbox: Only renders when `currentIndex !== null`
- Clicking lightbox overlay closes it

---

## What to Change for Similar Questions

### To add/remove images
Edit the `images` array in `App.jsx`:
```javascript
const images = [
    { src: 'your-image-url.jpg', name: 'Image 1' },
    { src: 'another-image.jpg', name: 'Image 2' }
];
```

### To use local images
Put images in a folder and reference them:
```javascript
{ src: 'images/myphoto.jpg', name: 'My Photo' }
```

### To change image size
Modify in `styles.css`:
```css
.gallery img {
    width: 300px;
    height: 300px;
}
```

### To add navigation arrows (prev/next)
Add state and functions in App.jsx:
```javascript
const goPrev = () => setCurrentIndex(currentIndex > 0 ? currentIndex - 1 : images.length - 1);
const goNext = () => setCurrentIndex(currentIndex < images.length - 1 ? currentIndex + 1 : 0);
```
Add buttons in JSX:
```jsx
<span onClick={goPrev}>&#10094;</span>
<span onClick={goNext}>&#10095;</span>
```

### To add filtering/categories
- Add category to image objects: `{ src: '...', category: 'nature' }`
- Add state for selected category
- Filter images before mapping

### To add animations
Add CSS transitions in `styles.css`:
```css
.gallery img {
    transition: transform 0.3s;
}
.gallery img:hover {
    transform: scale(1.05);
}
```

### For a production React app
Use create-react-app or Vite:
```bash
npx create-react-app image-gallery
# Then copy App.jsx code into src/App.js
```