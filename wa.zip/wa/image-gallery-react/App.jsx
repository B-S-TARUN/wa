const { useState } = React;

function App() {
    const images = [
        { src: 'https://picsum.photos/400/400?random=1', name: 'Image 1' },
        { src: 'https://picsum.photos/400/400?random=2', name: 'Image 2' },
        { src: 'https://picsum.photos/400/400?random=3', name: 'Image 3' },
        { src: 'https://picsum.photos/400/400?random=4', name: 'Image 4' },
        { src: 'https://picsum.photos/400/400?random=5', name: 'Image 5' },
        { src: 'https://picsum.photos/400/400?random=6', name: 'Image 6' },
        { src: 'https://picsum.photos/400/400?random=7', name: 'Image 7' },
        { src: 'https://picsum.photos/400/400?random=8', name: 'Image 8' }
    ];

    const [currentIndex, setCurrentIndex] = useState(null);

    const openLightbox = (index) => {
        setCurrentIndex(index);
    };

    const closeLightbox = () => {
        setCurrentIndex(null);
    };

    return (
        <div>
            <h1>Image Gallery</h1>
            <div className="gallery">
                {images.map((image, index) => (
                    <img
                        key={index}
                        src={image.src}
                        alt={image.name}
                        onClick={() => openLightbox(index)}
                    />
                ))}
            </div>
            {currentIndex !== null && (
                <div className="lightbox" onClick={closeLightbox}>
                    <span className="close" onClick={closeLightbox}>&times;</span>
                    <img src={images[currentIndex].src} alt={images[currentIndex].name} />
                </div>
            )}
        </div>
    );
}