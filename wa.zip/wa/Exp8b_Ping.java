// ================================================================
// EXPERIMENT 8b : PING simulation in Java
// ================================================================
// Real ping uses ICMP which Java cannot send directly, so we
// simulate ping using two methods:
//   Method 1 : InetAddress.isReachable()  (ICMP/ECHO port based)
//   Method 2 : TCP echo on port 7 (like classic echo service)
// Usage: java Exp8b_Ping www.google.com
// ================================================================
import java.net.*;

public class Exp8b_Ping {
    public static void main(String[] args) throws Exception {

        String host = (args.length > 0) ? args[0] : "www.google.com";
        InetAddress addr = InetAddress.getByName(host);

        System.out.println("Pinging " + host + " [" + addr.getHostAddress() + "]");
        System.out.println("--------------------------------------------------");

        int sent = 4, received = 0;
        long totalTime = 0;

        for (int i = 1; i <= sent; i++) {
            long start = System.currentTimeMillis();
            boolean ok = addr.isReachable(3000);          // timeout 3 sec
            long time = System.currentTimeMillis() - start;

            if (ok) {
                received++;
                totalTime += time;
                System.out.println("Reply from " + addr.getHostAddress() +
                        ": bytes=32 time=" + time + "ms  (seq " + i + ")");
            } else {
                System.out.println("Request timed out. (seq " + i + ")");
            }
            Thread.sleep(1000);                           // 1 sec between pings
        }

        System.out.println("--------------------------------------------------");
        System.out.println("Ping statistics for " + addr.getHostAddress() + ":");
        System.out.println("   Packets: Sent = " + sent + ", Received = " + received +
                ", Lost = " + (sent - received) + " (" + (100 * (sent - received) / sent) + "% loss)");
        if (received > 0)
            System.out.println("   Approximate round trip: min/avg = " +
                    (totalTime / received) + "ms");
    }
}
