// ================================================================
// EXPERIMENT 11 : REMOTE METHOD INVOCATION (RMI)
// ================================================================
// A client calls a method that actually runs on the server.
// Program adds two numbers on the server and returns the result.
//
// HOW TO RUN (4 steps) :
//   1. javac Exp11_Addition.java
//   2. start rmiregistry          (separate cmd window)
//   3. java Exp11_RMIServer       (separate cmd window)
//   4. java Exp11_RMIClient
// ================================================================
import java.rmi.*;
import java.rmi.server.*;

// ---------------- 1. REMOTE INTERFACE ----------------
interface Addition extends Remote {
    int add(int a, int b) throws RemoteException;
}

// ---------------- 2. REMOTE IMPLEMENTATION ----------------
class AdditionImpl extends UnicastRemoteObject implements Addition {
    AdditionImpl() throws RemoteException { }         // constructor

    public int add(int a, int b) throws RemoteException {
        System.out.println("Server: add(" + a + "," + b + ") called");
        return a + b;                                  // runs on the SERVER
    }
}

// ---------------- 3. RMI SERVER ----------------
public class Exp11_Addition {          // class with main = server
    public static void main(String[] args) throws Exception {
        // create the remote object
        AdditionImpl impl = new AdditionImpl();

        // bind it in the RMI registry with a name
        java.rmi.registry.LocateRegistry.createRegistry(1099); // start registry if not running
        Naming.rebind("rmi://localhost/Addition", impl);

        System.out.println("RMI Server ready. Object bound as 'Addition'...");
    }
}

// ---------------- 4. RMI CLIENT (separate file) ----------------
// Save the below as Exp11_RMIClient.java
// ----------------------------------------------------------------
// import java.rmi.*;
// public class Exp11_RMIClient {
//     public static void main(String[] args) throws Exception {
//         // lookup the remote object in the registry
//         Addition a = (Addition) Naming.lookup("rmi://localhost/Addition");
//         System.out.println("Remote call add(10,20) = " + a.add(10, 20));
//     }
// }
