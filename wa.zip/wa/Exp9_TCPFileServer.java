// ================================================================
// EXPERIMENT 9 : FILE TRANSFER SERVER (TCP)
// ================================================================
// Receives a file from the client and saves it as received_<name>.
// Run:  java Exp9_TCPFileServer   (start BEFORE the client)
// ================================================================
import java.io.*;
import java.net.*;

public class Exp9_TCPFileServer {
    public static void main(String[] args) throws Exception {
        ServerSocket ss = new ServerSocket(9000);
        System.out.println("File Server waiting on port 9000...");

        Socket s = ss.accept();
        System.out.println("Client connected: " + s.getInetAddress());

        DataInputStream in = new DataInputStream(
                new BufferedInputStream(s.getInputStream()));

        // 1. receive file name and size
        String fname = in.readUTF();
        long size = in.readLong();
        System.out.println("Receiving file: " + fname + " (" + size + " bytes)");

        // 2. receive file content
        FileOutputStream fos = new FileOutputStream("received_" + fname);
        byte[] buf = new byte[4096];
        long remaining = size;
        int n;
        while (remaining > 0 &&
               (n = in.read(buf, 0, (int)Math.min(buf.length, remaining))) > 0) {
            fos.write(buf, 0, n);
            remaining -= n;
        }
        fos.close();
        System.out.println("File received successfully as received_" + fname);

        s.close();
        ss.close();
    }
}
