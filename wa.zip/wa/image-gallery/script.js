const gallery = document.getElementById('gallery');
const lightbox = document.getElementById('lightbox');
const lightboxImage = document.getElementById('lightboxImage');
const closeLightbox = document.getElementById('closeLightbox');

const images = [
    { src: 'https://picsum.photos/400/400?random=1', name: 'Image 1' },
    { src: 'https://picsum.photos/400/400?random=2', name: 'Image 2' },
    { src: 'https://picsum.photos/400/400?random=3', name: 'Image 3' },
    { src: 'https://picsum.photos/400/400?random=4', name: 'Image 4' },
    { src: 'https://picsum.photos/400/400?random=5', name: 'Image 5' },
    { src: 'https://picsum.photos/400/400?random=6', name: 'Image 6' },
    { src: 'https://picsum.photos/400/400?random=7', name: 'Image 7' },
    { src: 'https://picsum.photos/400/400?random=8', name: 'Image 8' }
];

let currentIndex = 0;

function displayImages() {
    images.forEach((image, index) => {
        const img = document.createElement('img');
        img.src = image.src;
        img.alt = image.name;
        img.onclick = () => openLightbox(index);
        gallery.appendChild(img);
    });
}

function openLightbox(index) {
    currentIndex = index;
    lightboxImage.src = images[index].src;
    lightbox.classList.remove('hidden');
}

function close() {
    lightbox.classList.add('hidden');
}

closeLightbox.onclick = close;

lightbox.onclick = (e) => {
    if (e.target === lightbox) close();
};

displayImages();