# Implementation Guide - Question 1: Image Gallery (HTML, CSS, JS)

## How to Run

1. **Create a folder** on your computer (e.g., `image-gallery`)
2. **Create three files** inside:
   - `index.html`
   - `styles.css`
   - `script.js`
3. **Copy the code** from the respective files above into each file
4. **Open index.html** in any web browser (double-click or drag into browser)

That's it! No server, no installation required.

---

## Basic Logic

### 1. HTML Structure
- Contains a gallery container (`<div id="gallery">`) where images are displayed
- Contains a lightbox overlay (`<div id="lightbox">`) hidden by default for viewing enlarged images
- Loads CSS and JavaScript files

### 2. CSS Styling
- Uses **flexbox** to display images in a responsive grid
- Lightbox uses `position: fixed` to cover the entire screen
- `.hidden` class toggles lightbox visibility

### 3. JavaScript Logic
- **Array of images**: `const images = [{ src: '...', name: '...' }, ...]`
- **displayImages()**: Loops through array and creates `<img>` elements, adds click listener to open lightbox
- **openLightbox(index)**: Shows lightbox, sets the image source to clicked image
- **close()**: Hides lightbox when clicking X or outside the image

---

## What to Change for Similar Questions

### To add/remove images
Edit the `images` array in `script.js`:
```javascript
const images = [
    { src: 'your-image-url.jpg', name: 'Image 1' },
    { src: 'another-image.jpg', name: 'Image 2' }
];
```

### To use local images
Place images in a folder and use relative paths:
```javascript
{ src: 'images/myphoto.jpg', name: 'My Photo' }
```

### To change image size
Modify in `styles.css`:
```css
.gallery img {
    width: 300px;  /* Change width */
    height: 300px; /* Change height */
}
```

### To remove lightbox functionality

To keep only the basic gallery grid display (no lightbox):

**index.html:**
- Remove lines 16-19 (the lightbox `<div>` and its contents)

**script.js:**
- Remove lines 2-4 (the lightbox element references)
- Remove `currentIndex` variable (line 17)
- In `displayImages()`, remove the `onclick` handler (line 24)
- Remove `openLightbox()` function (lines 29-33)
- Remove `close()` function (lines 35-37)
- Remove lines 39-43 (event listeners)

**styles.css:**
- Remove `.lightbox`, `.lightbox.hidden`, `.lightbox img`, and `.close` rules (lines 20-48)
- Remove `cursor: pointer` from `.gallery img` (line 17)

### To add filtering (e.g., by category)
- Add data attributes to images: `{ src: '...', category: 'nature' }`
- Add filter dropdown in HTML
- Filter array before displaying

### To add a simple grid layout instead of flexbox
Change in `styles.css`:
```css
.gallery {
    display: grid;
    grid-template-columns: repeat(3, 1fr); /* 3 columns */
    gap: 10px;
}
```