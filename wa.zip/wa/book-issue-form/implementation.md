# Implementation Guide - Question 3: Book Issue Form (HTML, CSS, JS)

## How to Run

1. **Create a folder** named `book-issue-form`
2. **Create three files** inside:
   - `index.html`
   - `styles.css`
   - `script.js`
3. **Copy the code** from the respective files above into each file
4. **Open index.html** in any web browser

No server needed - runs entirely in browser.

---

## Basic Logic

### 1. HTML Structure
- Form with three input fields: Student ID, Book Name, Issue Date
- Each field has a paired `<span class="error">` for displaying validation messages
- Form submits to JavaScript (not a server)

### 2. JavaScript Validation Functions
- **validateStudentId()**: Checks required + alphanumeric 4-10 chars regex
- **validateBookName()**: Checks required + minimum 2 characters
- **validateIssueDate()**: Checks required + date not in past

### 3. Event Listeners
- **blur events**: Validate each field when user leaves it
- **submit event**: Validates all fields before allowing submission

### 4. Error Display
- `showError()`: Adds error message + red border
- `clearError()`: Removes error message + red border

---

## What to Change for Similar Questions

### To add a new field
HTML - add field:
```html
<div class="form-group">
    <label for="newField">New Field</label>
    <input type="text" id="newField" name="newField">
    <span class="error" id="newFieldError"></span>
</div>
```

JavaScript - add validation:
```javascript
function validateNewField() {
    const value = document.getElementById('newField').value.trim();
    if (value === '') {
        showError(document.getElementById('newField'), 'newFieldError', 'Required');
        return false;
    }
    // Add more validation rules...
    clearError(document.getElementById('newField'), 'newFieldError');
    return true;
}

// Add event listener
document.getElementById('newField').addEventListener('blur', validateNewField);
```

### To change validation rules
Example - Student ID with numbers only:
```javascript
function validateStudentId() {
    const value = studentId.value.trim();
    if (value === '') {
        showError(studentId, 'studentIdError', 'Required');
        return false;
    }
    if (!/^\d+$/.test(value)) {  // Numbers only
        showError(studentId, 'studentIdError', 'Must contain only numbers');
        return false;
    }
    clearError(studentId, 'studentIdError');
    return true;
}
```

### To change error message style
Modify in `styles.css`:
```css
.error {
    color: #e74c3c;
    font-size: 12px;
    display: block;
    margin-top: 5px;
    font-weight: bold;  /* Add styling */
}
```

### To add database submission
Replace alert in submit handler:
```javascript
form.addEventListener('submit', (e) => {
    e.preventDefault();
    if (isValid) {
        fetch('/api/issue-book', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                studentId: studentId.value,
                bookName: bookName.value,
                issueDate: issueDate.value
            })
        })
        .then(res => res.json())
        .then(data => alert('Success!'))
        .catch(err => alert('Error: ' + err));
    }
});
```

### To validate on keyup instead of blur
```javascript
// Replace blur with keyup
studentId.addEventListener('keyup', validateStudentId);
```

### To add auto-fill today's date
```javascript
// In JavaScript
document.getElementById('issueDate').value = new Date().toISOString().split('T')[0];
```