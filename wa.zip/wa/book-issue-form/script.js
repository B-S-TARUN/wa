const form = document.getElementById('issueForm');
const studentId = document.getElementById('studentId');
const bookName = document.getElementById('bookName');
const issueDate = document.getElementById('issueDate');

function showError(input, errorId, message) {
    const errorSpan = document.getElementById(errorId);
    errorSpan.textContent = message;
    input.classList.add('error');
}

function clearError(input, errorId) {
    const errorSpan = document.getElementById(errorId);
    errorSpan.textContent = '';
    input.classList.remove('error');
}

function validateStudentId() {
    const value = studentId.value.trim();
    if (value === '') {
        showError(studentId, 'studentIdError', 'Student ID is required');
        return false;
    }
    if (!/^[A-Z0-9]{4,10}$/i.test(value)) {
        showError(studentId, 'studentIdError', 'Student ID must be 4-10 alphanumeric characters');
        return false;
    }
    clearError(studentId, 'studentIdError');
    return true;
}

function validateBookName() {
    const value = bookName.value.trim();
    if (value === '') {
        showError(bookName, 'bookNameError', 'Book Name is required');
        return false;
    }
    if (value.length < 2) {
        showError(bookName, 'bookNameError', 'Book Name must be at least 2 characters');
        return false;
    }
    clearError(bookName, 'bookNameError');
    return true;
}

function validateIssueDate() {
    const value = issueDate.value;
    if (value === '') {
        showError(issueDate, 'issueDateError', 'Issue Date is required');
        return false;
    }
    const selectedDate = new Date(value);
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    if (selectedDate < today) {
        showError(issueDate, 'issueDateError', 'Issue Date cannot be in the past');
        return false;
    }
    clearError(issueDate, 'issueDateError');
    return true;
}

studentId.addEventListener('blur', validateStudentId);
bookName.addEventListener('blur', validateBookName);
issueDate.addEventListener('blur', validateIssueDate);

form.addEventListener('submit', (e) => {
    e.preventDefault();
    
    const isStudentIdValid = validateStudentId();
    const isBookNameValid = validateBookName();
    const isIssueDateValid = validateIssueDate();

    if (isStudentIdValid && isBookNameValid && isIssueDateValid) {
        alert('Book issued successfully!\n\nStudent ID: ' + studentId.value + '\nBook: ' + bookName.value + '\nDate: ' + issueDate.value);
        form.reset();
    }
});