// ================================================================
// EXPERIMENT 9 : FILE TRANSFER CLIENT (TCP)
// ================================================================
// Sends a file to the server: first the name + size, then content.
// Run:  java Exp9_TCPFileClient <filename>
// e.g.  java Exp9_TCPFileClient test.txt
// ================================================================
import java.io.*;
import java.net.*;

public class Exp9_TCPFileClient {
    public static void main(String[] args) throws Exception {
        String fname = (args.length > 0) ? args[0] : "test.txt";
        File f = new File(fname);
        if (!f.exists()) {
            System.out.println("File not found: " + fname);
            return;
        }

        Socket s = new Socket("localhost", 9000);
        System.out.println("Connected. Sending file: " + fname);

        DataOutputStream out = new DataOutputStream(
                new BufferedOutputStream(s.getOutputStream()));

        // 1. send file name and size
        out.writeUTF(f.getName());
        out.writeLong(f.length());

        // 2. send file content
        FileInputStream fis = new FileInputStream(f);
        byte[] buf = new byte[4096];
        int n;
        while ((n = fis.read(buf)) > 0)
            out.write(buf, 0, n);

        out.flush();
        fis.close();
        System.out.println("File sent successfully (" + f.length() + " bytes).");
        out.close();
        s.close();
    }
}
