// ================================================================
// EXPERIMENT 4 : Locate the Next Hop Router's IP and MAC Address
// ================================================================
// On Windows the default gateway is stored in the registry, so we
// read it with the "route print" command, then find its MAC using
// the ARP cache ("arp -a").  (Pure-Java: InetAddress of gateway +
// isReachable, then MAC from the ARP table.)
// ================================================================
import java.io.*;
import java.util.*;
import java.util.regex.*;

public class Exp4_NextHopRouter {
    public static void main(String[] args) throws Exception {

        // ---------- Step 1 : find default gateway IP from route table ----------
        String gatewayIp = null;
        Process p = Runtime.getRuntime().exec(new String[]{ "route", "print" });
        BufferedReader br = new BufferedReader(new InputStreamReader(p.getInputStream()));
        String line;
        boolean inActiveRoutes = false;
        while ((line = br.readLine()) != null) {
            if (line.contains("Active Routes")) { inActiveRoutes = true; continue; }
            if (line.contains("Persistent Routes")) { inActiveRoutes = false; }
            if (inActiveRoutes) {
                // lines look like:   0.0.0.0    0.0.0.0    192.168.1.1    192.168.1.5    25
                String[] t = line.trim().split("\\s+");
                if (t.length >= 5 && t[0].equals("0.0.0.0") && t[1].equals("0.0.0.0")) {
                    gatewayIp = t[2];      // third column = gateway
                }
            }
        }
        br.close();

        if (gatewayIp == null) {
            System.out.println("Default gateway not found. Try 'route print' manually.");
            return;
        }

        System.out.println("Next Hop Router (Default Gateway) IP : " + gatewayIp);

        // ---------- Step 2 : make sure it is in the ARP cache ----------
        // Ping it once so Windows learns its MAC address.
        Process ping = Runtime.getRuntime().exec(new String[]{ "ping", "-n", "1", "-w", "1000", gatewayIp });
        ping.waitFor();

        // ---------- Step 3 : read MAC address from ARP cache ----------
        Process arp = Runtime.getRuntime().exec(new String[]{ "arp", "-a", gatewayIp });
        BufferedReader ar = new BufferedReader(new InputStreamReader(arp.getInputStream()));
        Pattern mac = Pattern.compile("([0-9a-fA-F]{2}-){5}[0-9a-fA-F]{2}");
        while ((line = ar.readLine()) != null) {
            Matcher m = mac.matcher(line);
            if (m.find()) {
                System.out.println("Next Hop Router MAC Address          : " + m.group());
            }
        }
        ar.close();

        // ---------- Step 4 : (pure java) name of the gateway ----------
        System.out.println("Gateway Host Name                    : " +
                java.net.InetAddress.getByName(gatewayIp).getCanonicalHostName());
    }
}
