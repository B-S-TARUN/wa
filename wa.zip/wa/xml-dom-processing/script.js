let xmlDoc = null;
let booksData = [];

async function loadXML() {
    try {
        const response = await fetch('books.xml');
        const xmlText = await response.text();
        
        const parser = new DOMParser();
        xmlDoc = parser.parseFromString(xmlText, 'text/xml');
        
        const parseError = xmlDoc.querySelector('parsererror');
        if (parseError) {
            throw new Error('XML Parse Error: ' + parseError.textContent);
        }
        
        parseBooks();
        displayBooks();
        
        document.getElementById('output').textContent = 'XML loaded successfully! Total books: ' + booksData.length;
    } catch (error) {
        document.getElementById('output').innerHTML = '<div class="error">Error loading XML: ' + error.message + '</div>';
    }
}

function parseBooks() {
    booksData = [];
    const books = xmlDoc.getElementsByTagName('book');
    
    for (let i = 0; i < books.length; i++) {
        const book = books[i];
        booksData.push({
            id: book.getElementsByTagName('id')[0]?.textContent || '',
            title: book.getElementsByTagName('title')[0]?.textContent || '',
            author: book.getElementsByTagName('author')[0]?.textContent || '',
            year: book.getElementsByTagName('year')[0]?.textContent || '',
            category: book.getElementsByTagName('category')[0]?.textContent || ''
        });
    }
}

function displayBooks() {
    const categoryFilter = document.getElementById('categoryFilter').value;
    const sortBy = document.getElementById('sortBy').value;
    
    let filtered = booksData;
    
    if (categoryFilter !== 'all') {
        filtered = booksData.filter(book => book.category === categoryFilter);
    }
    
    filtered.sort((a, b) => {
        if (sortBy === 'id') {
            return parseInt(a.id) - parseInt(b.id);
        } else if (sortBy === 'title') {
            return a.title.localeCompare(b.title);
        } else if (sortBy === 'year') {
            return parseInt(b.year) - parseInt(a.year);
        }
        return 0;
    });
    
    const tbody = document.getElementById('bookTableBody');
    tbody.innerHTML = '';
    
    filtered.forEach(book => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${book.id}</td>
            <td>${book.title}</td>
            <td>${book.author}</td>
            <td>${book.year}</td>
            <td class="category-${book.category}">${book.category}</td>
        `;
        tbody.appendChild(row);
    });
}

function showRawXML() {
    const serializer = new XMLSerializer();
    const xmlString = serializer.serializeToString(xmlDoc);
    document.getElementById('output').textContent = xmlString;
}

function searchBooks(query) {
    query = query.toLowerCase();
    const filtered = booksData.filter(book => 
        book.title.toLowerCase().includes(query) ||
        book.author.toLowerCase().includes(query)
    );
    
    const tbody = document.getElementById('bookTableBody');
    tbody.innerHTML = '';
    
    filtered.forEach(book => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${book.id}</td>
            <td>${book.title}</td>
            <td>${book.author}</td>
            <td>${book.year}</td>
            <td>${book.category}</td>
        `;
        tbody.appendChild(row);
    });
}

function getBookById(id) {
    return booksData.find(book => book.id === id);
}

function addBook(newBook) {
    const library = xmlDoc.documentElement;
    const book = xmlDoc.createElement('book');
    
    const id = xmlDoc.createElement('id');
    id.textContent = newBook.id;
    const title = xmlDoc.createElement('title');
    title.textContent = newBook.title;
    const author = xmlDoc.createElement('author');
    author.textContent = newBook.author;
    const year = xmlDoc.createElement('year');
    year.textContent = newBook.year;
    const category = xmlDoc.createElement('category');
    category.textContent = newBook.category;
    
    book.appendChild(id);
    book.appendChild(title);
    book.appendChild(author);
    book.appendChild(year);
    book.appendChild(category);
    library.appendChild(book);
    
    parseBooks();
    displayBooks();
}

function deleteBook(id) {
    const books = xmlDoc.getElementsByTagName('book');
    for (let i = 0; i < books.length; i++) {
        const bookId = books[i].getElementsByTagName('id')[0]?.textContent;
        if (bookId === id) {
            books[i].parentNode.removeChild(books[i]);
            break;
        }
    }
    
    parseBooks();
    displayBooks();
}

loadXML();