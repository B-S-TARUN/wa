// ================================================================
// EXPERIMENT 8a : ECHO CLIENT (UDP)
// ================================================================
// Sends a typed message to the echo server and prints the echo.
// Run:  java Exp8a_EchoClient   (after starting the server)
// ================================================================
import java.net.*;
import java.io.*;

public class Exp8a_EchoClient {
    public static void main(String[] args) throws Exception {
        DatagramSocket ds = new DatagramSocket();
        InetAddress server = InetAddress.getByName("localhost");
        BufferedReader kb = new BufferedReader(
                new InputStreamReader(System.in));
        byte[] buf = new byte[1024];

        while (true) {
            System.out.print("Enter message (exit to quit): ");
            String msg = kb.readLine();
            if (msg == null || msg.equalsIgnoreCase("exit")) break;

            ds.send(new DatagramPacket(msg.getBytes(), msg.getBytes().length,
                                       server, 7000));           // send

            DatagramPacket res = new DatagramPacket(buf, buf.length);
            ds.receive(res);                                     // receive echo
            System.out.println("Echo from server: " +
                    new String(res.getData(), 0, res.getLength()));
        }
        ds.close();
    }
}
