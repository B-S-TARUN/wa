// ================================================================
// EXPERIMENT 10 : FILE TRANSFER CLIENT (UDP)
// ================================================================
// Sends file name, then file in 1000-byte chunks tagged with a
// sequence number ("seq:data"), then an END marker with the total.
// Run:  java Exp10_UDPFileClient <filename>
// e.g.  java Exp10_UDPFileClient test.txt
// ================================================================
import java.io.*;
import java.net.*;

public class Exp10_UDPFileClient {
    public static void main(String[] args) throws Exception {
        String fname = (args.length > 0) ? args[0] : "test.txt";
        File f = new File(fname);
        if (!f.exists()) { System.out.println("File not found: " + fname); return; }

        InetAddress server = InetAddress.getByName("localhost");
        DatagramSocket ds = new DatagramSocket();

        // send file name
        byte[] name = ("NAME:" + f.getName()).getBytes();
        ds.send(new DatagramPacket(name, name.length, server, 9500));

        // send file in chunks of 1000 bytes: "seq:data"
        FileInputStream fis = new FileInputStream(f);
        byte[] buf = new byte[1000];
        int seq = 0, n;
        while ((n = fis.read(buf)) > 0) {
            byte[] head = (seq + ":").getBytes();
            byte[] pkt = new byte[head.length + n];
            System.arraycopy(head, 0, pkt, 0, head.length);
            System.arraycopy(buf, 0, pkt, head.length, n);
            ds.send(new DatagramPacket(pkt, pkt.length, server, 9500));
            seq++;
            Thread.sleep(5);          // small delay so UDP packets are not lost
        }
        fis.close();

        // send end marker with total chunk count
        byte[] end = ("END:" + seq).getBytes();
        ds.send(new DatagramPacket(end, end.length, server, 9500));
        System.out.println("File sent in " + seq + " UDP packets.");
        ds.close();
    }
}
