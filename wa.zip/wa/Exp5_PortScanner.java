// ================================================================
// EXPERIMENT 5 : Find Which Ports Are Currently In Use (Scanner)
// ================================================================
// Scans localhost ports and reports which are OPEN (in use).
// A port is open if we can connect a socket to it.
// Usage: java Exp5_PortScanner [startPort] [endPort]
// e.g.  java Exp5_PortScanner 1 1024
// ================================================================
import java.net.*;
import java.io.*;

public class Exp5_PortScanner {
    public static void main(String[] args) {

        int start = (args.length > 0) ? Integer.parseInt(args[0]) : 1;
        int end   = (args.length > 1) ? Integer.parseInt(args[1]) : 1024;

        System.out.println("Scanning ports " + start + " to " + end + " on localhost...");
        System.out.println("OPEN ports (currently in use):");

        int count = 0;
        for (int port = start; port <= end; port++) {
            try (Socket s = new Socket()) {
                // try to connect quickly; if it succeeds the port is in use
                s.connect(new InetSocketAddress("127.0.0.1", port), 200);
                s.close();
                String service = getServiceName(port);
                System.out.printf("  Port %-6d OPEN   (%s)%n", port, service);
                count++;
            } catch (Exception e) {
                // connection failed -> port is closed (not in use)
            }
        }
        System.out.println("Total OPEN ports found : " + count);
    }

    // common well-known port names
    static String getServiceName(int p) {
        switch (p) {
            case 21:  return "FTP";
            case 22:  return "SSH";
            case 23:  return "Telnet";
            case 25:  return "SMTP";
            case 53:  return "DNS";
            case 67:  return "DHCP Server";
            case 68:  return "DHCP Client";
            case 80:  return "HTTP";
            case 110: return "POP3";
            case 143: return "IMAP";
            case 443: return "HTTPS";
            case 445: return "SMB";
            case 3306: return "MySQL";
            case 3389: return "RDP";
            case 8080: return "HTTP-Proxy";
            case 1521: return "Oracle";
            default:  return "unknown service";
        }
    }
}
