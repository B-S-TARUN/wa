// ================================================================
// EXPERIMENT 6 : Local DNS Server + Resolve a Given Host Name
// ================================================================
// Uses JNDI DNS provider to ask the system DNS server
// ("sun.net.spi.nameservice.nameservers" not needed - JNDI reads
//  Windows DNS config) and prints the DNS server + resolved IPs.
// ================================================================
import java.io.*;
import javax.naming.*;
import javax.naming.directory.*;
import java.net.InetAddress;
import java.util.Hashtable;

public class Exp6_DNSResolver {
    public static void main(String[] args) throws Exception {

        String host = (args.length > 0) ? args[0] : "www.google.com";

        // ---------- Part A : find local DNS server ----------
        System.out.println("Local DNS Server(s) (from ipconfig):");
        Process p = Runtime.getRuntime().exec(new String[]{ "ipconfig", "/all" });
        BufferedReader br = new BufferedReader(
                new InputStreamReader(p.getInputStream(), "IBM437")); // console codepage
        String line;
        while ((line = br.readLine()) != null) {
            if (line.trim().startsWith("DNS Servers") ||
                line.trim().matches("\\d{1,3}(\\.\\d{1,3}){3}.*")) {  // continuation lines
                System.out.println("   " + line.trim());
            }
        }
        br.close();

        // ---------- Part B : resolve given host name using DNS ----------
        System.out.println("\nResolving \"" + host + "\" using DNS (JNDI):");

        Hashtable<String, String> env = new Hashtable<>();
        env.put(Context.INITIAL_CONTEXT_FACTORY, "com.sun.jndi.dns.DnsContextFactory");
        // no provider URL -> uses the DNS servers configured in Windows
        DirContext ctx = new InitialDirContext(env);

        Attributes attrs = ctx.getAttributes(host, new String[]{ "A", "AAAA" });

        boolean found = false;
        Attribute a = attrs.get("A");        // IPv4
        if (a != null) {
            for (int i = 0; i < a.size(); i++) {
                System.out.println("   IPv4 : " + a.get(i));
                found = true;
            }
        }
        Attribute aaaa = attrs.get("AAAA");  // IPv6
        if (aaaa != null) {
            for (int i = 0; i < aaaa.size(); i++) {
                System.out.println("   IPv6 : " + aaaa.get(i));
                found = true;
            }
        }
        if (!found) System.out.println("   No A/AAAA records found.");

        // ---------- Part C : simple way using InetAddress ----------
        System.out.println("\nUsing InetAddress.getByName:");
        InetAddress[] all = InetAddress.getAllByName(host);
        System.out.println("   Host name : " + all[0].getHostName());
        for (InetAddress ia : all)
            System.out.println("   IP        : " + ia.getHostAddress());
    }
}
