// ================================================================
// EXPERIMENT 10 : FILE TRANSFER SERVER (UDP)
// ================================================================
// Receives file chunks with sequence numbers, reorders them and
// rebuilds the file as udp_<name>.
// Run:  java Exp10_UDPFileServer   (start BEFORE the client)
// ================================================================
import java.io.*;
import java.net.*;
import java.util.*;

public class Exp10_UDPFileServer {
    public static void main(String[] args) throws Exception {
        DatagramSocket ds = new DatagramSocket(9500);
        System.out.println("UDP File Server waiting on port 9500...");
        TreeMap<Integer, byte[]> chunks = new TreeMap<>();   // sorted by seq no
        String fname = null;
        int total = -1;

        byte[] buf = new byte[1024];
        while (total < 0 || chunks.size() < total) {
            DatagramPacket p = new DatagramPacket(buf, buf.length);
            ds.receive(p);
            String s = new String(p.getData(), 0, p.getLength());

            if (s.startsWith("END:")) {                       // end marker
                total = Integer.parseInt(s.substring(4));
                System.out.println("End marker received. Total chunks = " + total);
            } else if (s.startsWith("NAME:")) {               // file name
                fname = s.substring(5);
                System.out.println("Receiving file: " + fname);
            } else {                                          // "seq:data"
                int colon = s.indexOf(':');
                int seq = Integer.parseInt(s.substring(0, colon));
                chunks.put(seq, Arrays.copyOfRange(
                        p.getData(), colon + 1, p.getLength()));
            }
        }
        ds.close();

        // join chunks in order and write file
        FileOutputStream fos = new FileOutputStream("udp_" + fname);
        for (int i = 0; i < total; i++)
            fos.write(chunks.get(i));
        fos.close();
        System.out.println("File received successfully as udp_" + fname);
    }
}
