// ================================================================
// EXPERIMENT 8a : ECHO SERVER (UDP)
// ================================================================
// Echoes back whatever the client sends, using datagram packets.
// Run:  java Exp8a_EchoServer   (start BEFORE the client)
// ================================================================
import java.net.*;

public class Exp8a_EchoServer {
    public static void main(String[] args) throws Exception {
        DatagramSocket ds = new DatagramSocket(7000);
        System.out.println("UDP Echo Server listening on port 7000...");
        byte[] buf = new byte[1024];

        while (true) {
            DatagramPacket req = new DatagramPacket(buf, buf.length);
            ds.receive(req);                                     // receive
            String msg = new String(req.getData(), 0, req.getLength());
            System.out.println("Client says: " + msg);

            DatagramPacket res = new DatagramPacket(             // echo back
                    req.getData(), req.getLength(),
                    req.getAddress(), req.getPort());
            ds.send(res);
        }
    }
}
